part of '../../levit_monitor.dart';

/// Log levels for Levit Monitor events.
///
/// These map to the underlying [Level] from the `logger` package.
enum LevitLogLevel {
  /// No output.
  off(Level.off),

  /// Fatal errors.
  fatal(Level.fatal),

  /// Error level.
  error(Level.error),

  /// Warning level.
  warning(Level.warning),

  /// Info level (default for DI events).
  info(Level.info),

  /// Debug level (default for init, dispose, graph changes).
  debug(Level.debug),

  /// Trace level (default for state changes).
  trace(Level.trace),

  /// All output.
  all(Level.all);

  final Level level;
  const LevitLogLevel(this.level);
}

/// Configuration for log level overrides per event type.
///
/// This allows fine-grained control over which events are logged at which level.
///
/// ```dart
/// ConsoleTransport(
///   levelOverrides: LevitLogLevelConfig(
///     stateChange: LevitLogLevel.debug, // Promote state changes to debug
///     diResolve: LevitLogLevel.off,     // Suppress DI resolve logs
///   ),
/// )
/// ```
class LevitLogLevelConfig {
  /// Log level for state change events.
  final LevitLogLevel? stateChange;

  /// Log level for batch events.
  final LevitLogLevel? batch;

  /// Log level for reactive init events.
  final LevitLogLevel? reactiveInit;

  /// Log level for reactive dispose events.
  final LevitLogLevel? reactiveDispose;

  /// Log level for graph change events.
  final LevitLogLevel? graphChange;

  /// Log level for DI register events.
  final LevitLogLevel? diRegister;

  /// Log level for DI resolve events.
  final LevitLogLevel? diResolve;

  /// Log level for DI delete events.
  final LevitLogLevel? diDelete;

  /// Log level for DI instance create events.
  final LevitLogLevel? diCreate;

  /// Log level for DI instance init events.
  final LevitLogLevel? diInit;

  /// Log level for listener added events.
  final LevitLogLevel? listenerAdd;

  /// Log level for listener removed events.
  final LevitLogLevel? listenerRemove;

  const LevitLogLevelConfig({
    this.stateChange,
    this.batch,
    this.reactiveInit,
    this.reactiveDispose,
    this.graphChange,
    this.diRegister,
    this.diResolve,
    this.diDelete,
    this.diCreate,
    this.diInit,
    this.listenerAdd,
    this.listenerRemove,
    this.reactiveError,
  });

  /// Log level for reactive error events.
  final LevitLogLevel? reactiveError;
}

/// A transport that logs events to the console using the `logger` package.
///
/// This transport provides structured logging with configurable log levels
/// for each event type. It uses the popular `logger` package for beautiful,
/// readable console output.
///
/// ## Default Log Levels
///
/// | Event Type | Default Level |
/// |------------|---------------|
/// | State Change | `trace` |
/// | Batch | `debug` |
/// | Reactive Init | `debug` |
/// | Reactive Dispose | `debug` |
/// | Graph Change | `debug` |
/// | DI Register | `info` |
/// | DI Resolve | `debug` |
/// | DI Delete | `info` |
/// | DI Create | `debug` |
/// | DI Init | `debug` |
///
/// ## Usage
///
/// ```dart
/// // Basic usage with defaults
/// LevitMonitor.attach(transport: ConsoleTransport());
///
/// // Customize minimum log level (hide trace/debug)
/// LevitMonitor.attach(
///   transport: ConsoleTransport(minLevel: LevitLogLevel.info),
/// );
///
/// // Override specific event levels
/// LevitMonitor.attach(
///   transport: ConsoleTransport(
///     levelOverrides: LevitLogLevelConfig(
///       stateChange: LevitLogLevel.debug,      // Promote state changes
///       diResolve: LevitLogLevel.off,          // Suppress resolve logs
///     ),
///   ),
/// );
/// ```
class ConsoleTransport extends LevitTransport {
  /// The minimum log level to output.
  ///
  /// Events below this level will be suppressed.
  final LevitLogLevel minLevel;

  /// Optional overrides for log levels per event type.
  final LevitLogLevelConfig? levelOverrides;

  /// The underlying logger instance.
  final Logger _logger;

  /// Creates a new [ConsoleTransport].
  ///
  /// * [minLevel]: Minimum log level to output. Defaults to [LevitLogLevel.trace].
  /// * [levelOverrides]: Optional per-event-type log level overrides.
  /// * [printer]: Optional custom [LogPrinter]. Defaults to [PrettyPrinter].
  ConsoleTransport({
    this.minLevel = LevitLogLevel.trace,
    this.levelOverrides,
    LogPrinter? printer,
  }) : _logger = Logger(
         filter: ProductionFilter(),
         level: minLevel.level,
         printer:
             printer ??
             PrettyPrinter(
               methodCount: 0,
               errorMethodCount: 0,
               lineLength: 80,
               colors: true,
               printEmojis: true,
               dateTimeFormat: DateTimeFormat.none,
             ),
       );

  @override
  void send(MonitorEvent event) {
    if (!_shouldLog(event)) return;

    final level = _levelFor(event);
    final message = _formatMessage(event);

    // ignore: unused_local_variable
    final category = switch (event) {
      LogEvent _ => 'LOG',
      CustomMonitorEvent _ => 'CUSTOM',
      ReactiveBatchEvent _ => 'STATE',
      DependencyEvent _ => 'DI',
      SnapshotEvent _ => 'SNAPSHOT',
      _ => 'OTHER',
    };

    _logger.log(level.level, message);
  }

  bool _shouldLog(MonitorEvent event) {
    final eventLevel = _levelFor(event);
    return eventLevel.level.index >= minLevel.level.index;
  }

  LevitLogLevel _levelFor(MonitorEvent event) {
    final overrides = levelOverrides;

    return switch (event) {
      _ScopeProgressEvent() => LevitLogLevel.info,
      FrozenMonitorEvent e => _frozenLevel(e),
      ReactiveMetadataEvent _ => LevitLogLevel.debug,
      ReactiveChangeEvent _ => overrides?.stateChange ?? LevitLogLevel.trace,
      ReactiveBatchEvent _ => overrides?.batch ?? LevitLogLevel.debug,
      ReactiveInitEvent _ => overrides?.reactiveInit ?? LevitLogLevel.debug,
      ReactiveDisposeEvent _ =>
        overrides?.reactiveDispose ?? LevitLogLevel.debug,
      ReactiveGraphChangeEvent _ =>
        overrides?.graphChange ?? LevitLogLevel.debug,
      DependencyRegisterEvent _ => overrides?.diRegister ?? LevitLogLevel.info,
      DependencyResolveEvent _ => overrides?.diResolve ?? LevitLogLevel.debug,
      DependencyDeleteEvent _ => overrides?.diDelete ?? LevitLogLevel.info,
      DependencyInstanceCreateEvent _ =>
        overrides?.diCreate ?? LevitLogLevel.debug,
      DependencyInstanceReadyEvent _ =>
        overrides?.diInit ?? LevitLogLevel.debug,
      ReactiveListenerAddedEvent _ =>
        overrides?.listenerAdd ?? LevitLogLevel.debug,
      ReactiveListenerRemovedEvent _ =>
        overrides?.listenerRemove ?? LevitLogLevel.debug,
      ReactiveErrorEvent _ => overrides?.reactiveError ?? LevitLogLevel.error,
      ScopeCreateEvent _ => LevitLogLevel.debug,
      ScopeDisposeEvent _ => LevitLogLevel.debug,
      SnapshotEvent _ => LevitLogLevel.debug, // Default for SnapshotEvent
      CustomMonitorEvent e => switch (e.level) {
        Level.off => LevitLogLevel.off,
        Level.fatal => LevitLogLevel.fatal,
        Level.error => LevitLogLevel.error,
        Level.warning => LevitLogLevel.warning,
        Level.info => LevitLogLevel.info,
        Level.debug => LevitLogLevel.debug,
        Level.trace => LevitLogLevel.trace,
        _ => LevitLogLevel.all,
      },
      LogEvent e => switch (e.level) {
        Level.off => LevitLogLevel.off,
        Level.fatal => LevitLogLevel.fatal,
        Level.error => LevitLogLevel.error,
        Level.warning => LevitLogLevel.warning,
        Level.info => LevitLogLevel.info,
        Level.debug => LevitLogLevel.debug,
        Level.trace => LevitLogLevel.trace,
        _ => LevitLogLevel.all,
      },
    };
  }

  LevitLogLevel _frozenLevel(FrozenMonitorEvent event) {
    final data = event.toJson();
    final explicit = data['level'];
    if (explicit != null) {
      return LevitLogLevel.values.firstWhere(
        (level) => level.name == explicit,
        orElse: () => LevitLogLevel.info,
      );
    }
    return switch (data['type']) {
      'scope_progress' => LevitLogLevel.info,
      'state_change' => levelOverrides?.stateChange ?? LevitLogLevel.trace,
      'batch' => levelOverrides?.batch ?? LevitLogLevel.debug,
      'reactive_init' => levelOverrides?.reactiveInit ?? LevitLogLevel.debug,
      'reactive_dispose' =>
        levelOverrides?.reactiveDispose ?? LevitLogLevel.debug,
      'graph_change' => levelOverrides?.graphChange ?? LevitLogLevel.debug,
      'di_register' => levelOverrides?.diRegister ?? LevitLogLevel.info,
      'di_resolve' => levelOverrides?.diResolve ?? LevitLogLevel.debug,
      'di_delete' => levelOverrides?.diDelete ?? LevitLogLevel.info,
      'di_instance_create' => levelOverrides?.diCreate ?? LevitLogLevel.debug,
      'di_instance_init' => levelOverrides?.diInit ?? LevitLogLevel.debug,
      'listener_add' => levelOverrides?.listenerAdd ?? LevitLogLevel.debug,
      'listener_remove' =>
        levelOverrides?.listenerRemove ?? LevitLogLevel.debug,
      'reactive_error' => levelOverrides?.reactiveError ?? LevitLogLevel.error,
      _ => LevitLogLevel.debug,
    };
  }

  String _formatMessage(MonitorEvent event) {
    String safeValue(dynamic value, {bool sensitive = false}) =>
        '${MonitorEvent._stringify(value, isSensitive: sensitive)}';

    return switch (event) {
      _ScopeProgressEvent e => jsonEncode(e.toJson()),
      FrozenMonitorEvent e => jsonEncode(e.toJson()),
      ReactiveMetadataEvent e => 'METADATA: ${e.reactive.name}',
      ReactiveChangeEvent e =>
        'VAL: ${e.reactive.name ?? '[anon]'} <${e.change.valueType}> -> ${safeValue(e.change.newValue, sensitive: e.reactive.isSensitive)}',
      ReactiveBatchEvent e =>
        'BATCH: ${e.change.batchId} (${e.change.length} changes)',
      ReactiveInitEvent e =>
        'INIT: ${e.reactive.name ?? '[anon]'} <${e.reactive.runtimeType}> = ${safeValue(e.reactive.value, sensitive: e.reactive.isSensitive)}',
      ReactiveDisposeEvent e => 'DISPOSE: ${e.reactive.name ?? '[anon]'}',
      ReactiveGraphChangeEvent e =>
        'GRAPH: ${e.reactive.name} dependencies changed',
      DependencyRegisterEvent e =>
        'DI REGISTER: ${e.key} in ${e.scopeName}#${e.scopeId} (${e.source})',
      DependencyResolveEvent e =>
        'DI RESOLVE: ${e.key} in ${e.scopeName}#${e.scopeId} (${e.source})',
      DependencyDeleteEvent e =>
        'DI DELETE: ${e.key} from ${e.scopeName}#${e.scopeId} (${e.source})',
      DependencyInstanceCreateEvent e => 'DI CREATE: ${e.key}',
      DependencyInstanceReadyEvent e => 'DI INIT: ${e.key}',
      ReactiveListenerAddedEvent e =>
        'LISTENER ADD: ${e.reactive.name ?? '[anon]'} (Context: ${e.context})',
      ReactiveListenerRemovedEvent e =>
        'Listener removed: ${e.reactive.name} (Context: ${e.context?.type})',
      ReactiveErrorEvent e =>
        'ERROR: ${e.reactive?.name ?? '[anon]'} - ${safeValue(e.error, sensitive: e.reactive?.isSensitive ?? false)}',
      ScopeCreateEvent e =>
        'SCOPE CREATE: ${e.scopeName}#${e.scopeId} (Parent: ${e.parentScopeId})',
      ScopeDisposeEvent e => 'SCOPE DISPOSE: ${e.scopeName}#${e.scopeId}',
      SnapshotEvent e => 'Snapshot sent (${e.state.length} items)',
      CustomMonitorEvent e =>
        'CUSTOM ${e.namespace}:${e.name} ${safeValue(e.toJson()['attributes'])}'
            '${e.error != null ? '\nError: ${safeValue(e.error, sensitive: e.sensitive)}' : ''}',
      LogEvent e =>
        'LOG: ${safeValue(e.data)}'
            '${e.error != null ? '\nError: ${safeValue(e.error)}' : ''}'
            '${e.stackTrace != null ? '\nStack: \n${e.stackTrace}' : ''}',
    };
  }

  @override
  Stream<void> get onConnect => const Stream<void>.empty();

  @override
  Future<void> close() async {
    _logger.close();
  }
}
