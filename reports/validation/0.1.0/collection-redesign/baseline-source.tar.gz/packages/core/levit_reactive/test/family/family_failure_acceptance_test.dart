import 'dart:async';

import 'package:levit_reactive/levit_reactive.dart';
import 'package:test/test.dart';

import '../core/cleanup_failure_acceptance_test.dart' show DisposeHook;

class Producer extends LxVar<int> {
  Producer(super.value);
  Object? readError;
  Object? cancelError;
  Object? drainError;
  Object? closeError;
  Completer<void>? gate;
  @override
  int get value {
    if (readError != null) throw readError!;
    return super.value;
  }

  @override
  void requestCancel() {
    super.requestCancel();
    if (cancelError != null) throw cancelError!;
  }

  @override
  Future<void> drain() async {
    await gate?.future;
    if (drainError != null) throw drainError!;
    await super.drain();
  }

  @override
  Future<void> close() async {
    await gate?.future;
    try {
      await super.close();
    } finally {
      if (closeError != null) throw closeError!;
    }
  }
}

Matcher failures(Iterable<Object> errors) => isA<LxCleanupException>().having(
  (e) => e.failures.map((f) => f.error),
  'failures',
  unorderedEquals(errors),
);

void main() {
  tearDown(LevitReactiveMiddleware.clear);

  test(
    'validates retention, keeps immutable keys and closes evicted handles',
    () async {
      expect(
        () => LxFamily(Producer.new, maxInactiveEntries: 0),
        throwsRangeError,
      );
      expect(
        () => LxFamily(Producer.new, gracePeriod: const Duration(seconds: -1)),
        throwsArgumentError,
      );
      final family = LxFamily<int, int, Producer>(
        Producer.new,
        name: 'numbers',
        debugKey: (_) => throw StateError('unsafe key'),
      );
      await family.refresh(1);
      final handle = family(1);
      expect(family.peek(1), same(handle));
      expect(family.peek(2), isNull);
      expect(handle.id, isPositive);
      expect(handle.resource.name, 'numbers[key]');
      expect(family.keys, [1]);
      expect(await family.evict(2), isFalse);
      await family.invalidateAll();
      expect(handle.isClosed, isTrue);
      expect(() => handle.addListener(() {}), throwsStateError);
      expect(() => handle.resource, throwsStateError);
      await family.close();
      expect(family.isClosing, isTrue);
    },
  );

  test(
    'failed initial read closes unattached producer and reports its cleanup',
    () async {
      final read = StateError('read');
      final cancel = StateError('cancel');
      final close = StateError('close');
      final producer = Producer(1)
        ..readError = read
        ..cancelError = cancel
        ..closeError = close;
      final family = LxFamily<int, int, Producer>((_) => producer);
      expect(() => family(1), throwsA(same(read)));
      expect(family.keys, isEmpty);
      await expectLater(family.close(), throwsA(failures([cancel, close])));
      expect(producer.isDisposed, isTrue);
    },
  );

  test(
    'failed producer reads remain observable and recover on next publication',
    () async {
      final producer = Producer(1);
      final family = LxFamily<int, int, Producer>((_) => producer);
      final handle = family(1);
      final error = StateError('read failed');
      final errors = <Object>[];
      final values = <int>[];
      final subscription = handle.stream.listen(
        values.add,
        onError: errors.add,
      );
      producer.readError = error;
      producer.refresh();
      await Future<void>.delayed(Duration.zero);
      expect(handle.refreshStackTrace, isNotNull);
      expect(handle.lastValue, 1);
      expect(errors, [error]);
      producer.readError = null;
      producer.value = 2;
      await Future<void>.delayed(Duration.zero);
      expect(values, [2]);
      expect(handle.refreshError, isNull);
      await subscription.cancel();
      await family.close();
    },
  );

  test(
    'refresh aggregates cancellation and close failures and permits retry',
    () async {
      final cancel = StateError('cancel');
      final close = StateError('close');
      var generation = 0;
      final family = LxFamily<int, int, Producer>(
        (_) => Producer(++generation),
      );
      final handle = family(1);
      handle.resource
        ..cancelError = cancel
        ..closeError = close;
      await expectLater(family.refresh(1), throwsA(failures([cancel, close])));
      expect(handle.refreshStackTrace, isNotNull);
      expect(handle.lastValue, 1);
      await family.refresh(1);
      expect(handle.value, 2);
      await family.close();
    },
  );

  for (final fail in [false, true]) {
    test('eviction waits for refreshing producer, failure=$fail', () async {
      final gate = Completer<void>();
      final error = StateError('old close');
      final family = LxFamily<int, int, Producer>(Producer.new);
      final handle = family(1);
      handle.resource
        ..gate = gate
        ..closeError = fail ? error : null;
      final refresh = family.refresh(1);
      final checkedRefresh = expectLater(
        refresh,
        throwsA(fail ? failures([error]) : isA<LxCancelledException>()),
      );
      final evicted = family.evict(1);
      final checkedEvict = fail
          ? expectLater(evicted, throwsA(failures([error])))
          : expectLater(evicted, completion(isTrue));
      final drained = family.drain();
      gate.complete();
      await checkedRefresh;
      await checkedEvict;
      await drained;
      expect(handle.isClosed, isTrue);
      if (fail) {
        await expectLater(family.close(), throwsA(failures([error])));
      } else {
        await family.close();
      }
    });
  }

  test(
    'family close aggregates drain, cancellation, observation and close failures',
    () async {
      final cancel = StateError('cancel');
      final drain = StateError('drain');
      final close = StateError('close');
      final observation = StateError('observation');
      final producer = Producer(1)
        ..cancelError = cancel
        ..drainError = drain
        ..closeError = close;
      final family = LxFamily<int, int, Producer>((_) => producer);
      final handle = family(1);
      LevitReactiveMiddleware.add(
        DisposeHook((next, reactive) {
          next();
          if (reactive.id == handle.id) throw observation;
        }),
      );
      await expectLater(
        family.close(),
        throwsA(failures([cancel, drain, close, observation])),
      );
      expect(handle.isClosed, isTrue);
      expect(family.isDisposed, isTrue);
    },
  );

  test(
    'close waits for a failed in-flight refresh and preserves its failure',
    () async {
      final gate = Completer<void>();
      final error = StateError('refresh cleanup');
      final family = LxFamily<int, int, Producer>(Producer.new);
      family(1).resource
        ..gate = gate
        ..closeError = error;
      final refresh = expectLater(
        family.refresh(1),
        throwsA(failures([error])),
      );
      final close = expectLater(family.close(), throwsA(failures([error])));
      gate.complete();
      await refresh;
      await close;
    },
  );

  test('family rejects self refresh and closure from owned worker', () async {
    final source = 0.lx;
    final finished = Completer<void>();
    late LxFamily<int, LxWorkerStat, LxWorker<int>> family;
    family = LxFamily(
      (_) => LxWorker.withContext(source, (_, _) async {
        expect(() => family.refresh(1), throwsStateError);
        expect(() => family.close(), throwsStateError);
        await expectLater(family.drain(), throwsStateError);
        finished.complete();
      }),
    );
    family(1);
    source.value++;
    await finished.future;
    await family.close();
    await source.close();
  });
}
