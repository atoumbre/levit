import 'dart:async';
import 'package:levit_reactive/levit_reactive.dart';
import 'package:test/test.dart';

void main() {
  test(
    'stable handle keeps direct, computed and worker subscriptions across refresh',
    () async {
      var generation = 0;
      final family = LxFamily<String, int, LxVar<int>>(
        (_) => (++generation).lx,
      );
      final handle = family('key');
      final previousResource = handle.resource;
      final computed = LxComputed(() => handle.value * 10);
      final changes = <int>[];
      computed.addListener(() => changes.add(computed.value));
      final watched = <int>[];
      final worker = LxWorker(handle, watched.add);
      var direct = 0;
      handle.addListener(() => direct++);
      await family.refresh('key');
      expect(family('key'), same(handle));
      expect(previousResource.isDisposed, isTrue);
      expect(handle.resource, isNot(same(previousResource)));
      expect(computed.value, 20);
      expect(changes, contains(20));
      expect(watched, contains(2));
      expect(direct, greaterThanOrEqualTo(2));
      handle.resource.value = 3;
      expect(computed.value, 30);
      expect(watched.last, 3);
      await worker.close();
      await computed.close();
      await family.close();
      expect(handle.isClosed, isTrue);
      expect(() => handle.value, throwsStateError);
    },
  );

  test(
    'refresh drains old producer, retains null and joins concurrent replacement',
    () async {
      final pending = Completer<int?>();
      var builds = 0;
      final family = LxFamily<String, LxStatus<int?>, LxFuture<int?>>((_) {
        builds++;
        return builds == 1
            ? LxFuture(pending.future, initial: 5)
            : LxFuture(Future.value(null));
      });
      final handle = family('key');
      final first = family.refresh('key');
      expect(identical(first, family.refresh('key')), isTrue);
      expect(handle.isReplacing, isTrue);
      expect(handle.value.valueOrNull, 5);
      expect(() => handle.resource, throwsStateError);
      expect(builds, 1);
      pending.complete(99);
      await first;
      await handle.resource.wait;
      expect(builds, 2);
      expect(handle.value, isA<LxSuccess<int?>>());
      expect(handle.value.valueOrNull, isNull);
      await family.close();
    },
  );

  test(
    'failed refresh remains observable and permits recovery on the same handle',
    () async {
      var fail = false;
      var builds = 0;
      final family = LxFamily<int, int, LxVar<int>>((_) {
        if (fail) throw StateError('fetch failed');
        return (++builds).lx;
      });
      final handle = family(1);
      var signals = 0;
      handle.addListener(() => signals++);
      fail = true;
      await expectLater(family.refresh(1), throwsStateError);
      expect(signals, greaterThanOrEqualTo(2));
      expect(handle.refreshError, isA<StateError>());
      expect(handle.lastValue, 1);
      expect(() => handle.value, throwsStateError);
      fail = false;
      await family.refresh(1);
      expect(handle.value, 2);
      expect(handle.refreshError, isNull);
      await family.close();
    },
  );

  test(
    'invalidation refreshes active entries and evicts inactive handles',
    () async {
      var builds = 0;
      final family = LxFamily<int, int, LxVar<int>>((_) => (++builds).lx);
      final active = family(1);
      void listener() {}
      active.addListener(listener);
      final inactive = family(2);
      expect(() => family.evict(1), throwsStateError);
      expect(await family.invalidate(1), isTrue);
      expect(active.value, 3);
      expect(await family.invalidate(2), isTrue);
      expect(inactive.isClosed, isTrue);
      expect(family.containsKey(2), isFalse);
      expect(await family.invalidate(99), isFalse);
      active.removeListener(listener);
      await family.close();
    },
  );

  test(
    'LRU bounds inactive entries while active entries stay pinned',
    () async {
      final family = LxFamily<int, int, LxVar<int>>(
        (key) => key.lx,
        maxInactiveEntries: 2,
      );
      final pinned = family(-1);
      pinned.addListener(() {});
      final oldest = family(1);
      final second = family(2);
      family(1); // Touch makes key 2 least recently used.
      family(3);
      expect(second.isClosed, isTrue);
      expect(oldest.isClosed, isFalse);
      expect(pinned.isClosed, isFalse);
      expect(family.length, 3);
      await family.close();
    },
  );

  test(
    'inactive grace eviction closes handles without evicting a newly active entry',
    () async {
      final family = LxFamily<int, int, LxVar<int>>(
        (key) => key.lx,
        gracePeriod: Duration.zero,
      );
      final inactive = family(1);
      final active = family(2);
      void listener() {}
      active.addListener(listener);
      await Future<void>.delayed(Duration.zero);
      expect(inactive.isClosed, isTrue);
      expect(active.isClosed, isFalse);
      active.removeListener(listener);
      await Future<void>.delayed(Duration.zero);
      expect(active.isClosed, isTrue);
      await family.close();
    },
  );

  test(
    'closure during refresh drains old producer and never constructs replacement',
    () async {
      final gate = Completer<int>();
      var builds = 0;
      final family = LxFamily<int, LxStatus<int>, LxFuture<int>>((key) {
        builds++;
        return LxFuture(gate.future);
      });
      final handle = family(1);
      final refresh = family.refresh(1);
      final expected = expectLater(
        refresh,
        throwsA(isA<LxCancelledException>()),
      );
      var done = false;
      final close = family.close().then((_) => done = true);
      await Future<void>.delayed(Duration.zero);
      expect(done, isFalse);
      gate.complete(1);
      await expected;
      await close;
      expect(builds, 1);
      expect(handle.isClosed, isTrue);
      expect(() => family(1), throwsStateError);
    },
  );

  test(
    'resource reads are tracked and key diagnostics are opaque by default',
    () async {
      final family = LxFamily<String, int, LxVar<int>>(
        (_) => 1.lx,
        name: 'users',
      );
      final handle = family('private@example.com');
      expect(handle.resource.name, startsWith('users['));
      expect(handle.resource.name, isNot(contains('private@example.com')));
      final selected = LxComputed(
        () => handle.isReplacing ? -1 : handle.resource.value,
      );
      selected.addListener(() {});
      expect(handle.isActive, isTrue);
      await family.refresh('private@example.com');
      expect(selected.value, 1);
      await selected.close();
      await family.close();
    },
  );
}
