part of '../levit_reactive.dart';

final class _LxFamilyFrame<T, R> {
  final T value;
  final R? resource;
  final bool replacing;
  final Object? error;
  final StackTrace? stackTrace;
  const _LxFamilyFrame(
    this.value,
    this.resource, {
    this.replacing = false,
    this.error,
    this.stackTrace,
  });
}

/// Stable observation of one family entry, independent of producer replacement.
/// Reading [resource] participates in dependency tracking and is unavailable while
/// replacement drains/rebuilds. Consumers may mutate that resource's domain state.
final class LxFamilyHandle<T, R extends LxReactive<T>>
    implements LxReadable<T> {
  final LxVar<_LxFamilyFrame<T, R>> _state;
  bool _closed = false;
  LxFamilyHandle._(T value, R resource, String? name)
    : _state = LxVar(_LxFamilyFrame(value, resource))..name = name;

  bool get isClosed => _closed;
  bool get isActive => _state.hasListener;
  bool get isReplacing => _state.value.replacing;
  Object? get refreshError => _state.value.error;
  StackTrace? get refreshStackTrace => _state.value.stackTrace;

  /// Retained published data, including null, even after a failed refresh.
  T get lastValue => _state.value.value;

  @override
  int get id => _state.id;

  T _read(_LxFamilyFrame<T, R> frame) {
    if (_closed) {
      throw StateError('This family handle has been evicted or closed.');
    }
    if (frame.error != null) {
      Error.throwWithStackTrace(
        frame.error!,
        frame.stackTrace ?? StackTrace.current,
      );
    }
    return frame.value;
  }

  @override
  T get value => _read(_state.value);

  R get resource {
    final frame = _state.value;
    if (_closed || frame.replacing || frame.resource == null) {
      throw StateError(
        'The family resource is unavailable during replacement or after closure.',
      );
    }
    return frame.resource!;
  }

  @override
  Stream<T> get stream => _state.stream.map(_read);
  @override
  void addListener(void Function() listener) {
    if (_closed) throw StateError('Cannot observe a closed family handle.');
    _state.addListener(listener);
  }

  @override
  void removeListener(void Function() listener) =>
      _state.removeListener(listener);

  void _publish(_LxFamilyFrame<T, R> frame) {
    if (!_closed) _state.value = frame;
  }

  Future<void> _close() {
    _closed = true;
    return _state.close();
  }
}

/// Keyed producers with stable handles and bounded inactive retention.
///
/// The family owns producers and handles. Refresh stops and drains the previous
/// producer before construction, preserving subscribers and the last value.
/// Active entries are pinned. Inactive entries expire after [gracePeriod] and use
/// least-recently-used eviction above [maxInactiveEntries]. Raw keys are excluded
/// from diagnostics unless [debugKey] explicitly supplies an application label.
class LxFamily<K, T, R extends LxReactive<T>> implements LxAsyncResource {
  final R Function(K key) _builder;
  final int maxInactiveEntries;
  final Duration gracePeriod;
  final String? name;
  final String Function(K key)? debugKey;
  final LinkedHashMap<K, _LxFamilyEntry<T, R>> _entries = LinkedHashMap();
  final Set<Future<void>> _retiring = {};
  final Set<R> _drainingResources = Set.identity();
  final List<AsyncError> _cleanupFailures = [];
  bool _closing = false;
  bool _disposed = false;
  Future<void>? _closingFuture;

  LxFamily(
    this._builder, {
    this.maxInactiveEntries = 128,
    this.gracePeriod = const Duration(seconds: 30),
    this.name,
    this.debugKey,
  }) {
    if (maxInactiveEntries < 1) {
      throw RangeError.value(maxInactiveEntries, 'maxInactiveEntries');
    }
    if (gracePeriod.isNegative) {
      throw ArgumentError.value(gracePeriod, 'gracePeriod');
    }
  }

  bool get isDisposed => _disposed;
  bool get isClosing => _closing;
  int get length => _entries.length;
  Iterable<K> get keys => List.unmodifiable(_entries.keys);
  bool containsKey(K key) => _entries.containsKey(key);

  /// Looks up a cached handle without creating or refreshing a producer.
  LxFamilyHandle<T, R>? peek(K key) => _entries[key]?.handle;

  void _ensureOpen() {
    if (_closing) {
      throw StateError('LxFamily${name == null ? '' : ' "$name"'} is closing.');
    }
  }

  LxFamilyHandle<T, R> call(K key) {
    _ensureOpen();
    var entry = _entries[key];
    if (entry == null) {
      final resource = _builder(key);
      final label = _diagnosticName(key);
      resource.name ??= label;
      late final LxFamilyHandle<T, R> handle;
      try {
        handle = LxFamilyHandle<T, R>._(resource.value, resource, label);
      } catch (_) {
        _closeUnattached(resource);
        rethrow;
      }
      entry = _LxFamilyEntry(handle, resource);
      _entries[key] = entry;
      final current = entry;
      current.activity = (active) {
        if (_closing || !identical(_entries[key], current)) return;
        if (active) {
          current.expiry?.cancel();
          current.expiry = null;
        } else {
          _touch(key, current);
        }
      };
      handle._state._addActivityObserver(current.activity!);
      _connect(current);
    }
    _touch(key, entry);
    return entry.handle;
  }

  void _connect(_LxFamilyEntry<T, R> entry) {
    final resource = entry.resource!;
    void publish() {
      if (_closing || entry.retired || !identical(entry.resource, resource)) {
        return;
      }
      try {
        entry.handle._publish(_LxFamilyFrame(resource.value, resource));
      } catch (error, stack) {
        entry.handle._publish(
          _LxFamilyFrame(
            entry.handle.lastValue,
            resource,
            error: error,
            stackTrace: stack,
          ),
        );
      }
    }

    entry.listener = publish;
    resource.addListener(publish);
    publish();
  }

  R? _disconnect(_LxFamilyEntry<T, R> entry) {
    final resource = entry.resource;
    if (resource != null && entry.listener != null) {
      resource.removeListener(entry.listener!);
    }
    entry.resource = null;
    entry.listener = null;
    return resource;
  }

  /// Joins a replacement already in progress. Failed construction/cleanup is
  /// published on the same handle and rethrown by this Future. A later refresh
  /// can retry; observing [LxFamilyHandle.lastValue] still exposes retained data.
  Future<void> refresh(K key) {
    _ensureOpen();
    if (!_entries.containsKey(key)) {
      call(key);
      return Future.value();
    }
    final handle = call(key);
    final entry = _entries[key]!;
    if (entry.refresh != null) return entry.refresh!;
    if (entry.resource != null &&
        LxExecutionContext.isExecuting(entry.resource!)) {
      throw StateError('A producer cannot refresh itself while executing.');
    }
    final complete = Completer<void>();
    entry.refresh = complete.future;
    // Record failures for callers without creating a second unhandled Future.
    complete.future.ignore();
    final old = _disconnect(entry);
    if (old != null) _drainingResources.add(old);
    handle._publish(_LxFamilyFrame(handle.lastValue, null, replacing: true));
    unawaited(() async {
      try {
        if (old != null) {
          final errors = <AsyncError>[];
          try {
            if (old is LxAsyncResource) {
              (old as LxAsyncResource).requestCancel();
            }
          } catch (error, stack) {
            errors.add(AsyncError(error, stack));
          }
          try {
            await old.close();
          } catch (error, stack) {
            errors.add(AsyncError(error, stack));
          }
          if (errors.isNotEmpty) throw LxCleanupException(errors);
        }
        if (_closing || entry.retired) throw const LxCancelledException();
        final next = _builder(key);
        next.name ??= _diagnosticName(key);
        entry.resource = next;
        _connect(entry);
        complete.complete();
      } catch (error, stack) {
        if (!_closing && !entry.retired) {
          handle._publish(
            _LxFamilyFrame(
              handle.lastValue,
              null,
              error: error,
              stackTrace: stack,
            ),
          );
        }
        complete.completeError(error, stack);
      } finally {
        entry.refresh = null;
        if (old != null) _drainingResources.remove(old);
      }
    }());
    return complete.future;
  }

  /// Refreshes an active entry and evicts an inactive one.
  Future<bool> invalidate(K key) async {
    _ensureOpen();
    final entry = _entries[key];
    if (entry == null) return false;
    if (entry.handle.isActive) {
      await refresh(key);
    } else {
      await evict(key);
    }
    return true;
  }

  /// Explicit eviction rejects active handles instead of disconnecting users.
  Future<bool> evict(K key) {
    _ensureOpen();
    final entry = _entries[key];
    if (entry == null) return Future.value(false);
    if (entry.handle.isActive) {
      throw StateError('Cannot evict an active family entry.');
    }
    return _retire(key, entry).then((_) => true);
  }

  Future<void> invalidateAll() async {
    for (final key in keys.toList()) {
      await invalidate(key);
    }
  }

  String? _diagnosticName(K key) {
    if (name == null) return null;
    String safe;
    try {
      safe =
          debugKey?.call(key) ?? key.hashCode.toUnsigned(32).toRadixString(16);
    } catch (_) {
      safe = 'key';
    }
    return '$name[$safe]';
  }

  void _touch(K key, _LxFamilyEntry<T, R> entry) {
    _entries.remove(key);
    _entries[key] = entry;
    entry.expiry?.cancel();
    entry.expiry = null;
    if (!entry.handle.isActive) {
      entry.expiry = Timer(gracePeriod, () {
        if (!_closing &&
            identical(_entries[key], entry) &&
            !entry.handle.isActive) {
          _retire(key, entry).ignore();
        }
      });
    }
    final inactive = _entries.entries
        .where((item) => !item.value.handle.isActive)
        .toList();
    for (final oldest in inactive.take(
      max(0, inactive.length - maxInactiveEntries),
    )) {
      _retire(oldest.key, oldest.value).ignore();
    }
  }

  Future<void> _retire(K key, _LxFamilyEntry<T, R> entry) {
    _entries.remove(key);
    entry.retired = true;
    entry.expiry?.cancel();
    entry.handle._state._removeActivityObserver(entry.activity!);
    final resource = _disconnect(entry);
    if (resource != null) _drainingResources.add(resource);
    _cancelResource(resource);
    final observationClosed = entry.handle._close();
    final operation = () async {
      final errors = <AsyncError>[];
      try {
        final pending = entry.refresh;
        if (pending != null) {
          try {
            await pending;
          } on LxCancelledException {
            /* Expected retirement. */
          } catch (error, stack) {
            errors.add(AsyncError(error, stack));
          }
        }
        try {
          await observationClosed;
        } catch (error, stack) {
          errors.add(AsyncError(error, stack));
        }
        if (resource != null) {
          try {
            await resource.close();
          } catch (error, stack) {
            errors.add(AsyncError(error, stack));
          }
        }
      } finally {
        if (resource != null) _drainingResources.remove(resource);
      }
      if (errors.isNotEmpty) throw LxCleanupException(errors);
    }();
    late final Future<void> tracked;
    tracked = operation
        .catchError((Object error, StackTrace stack) {
          _cleanupFailures.add(AsyncError(error, stack));
        })
        .whenComplete(() => _retiring.remove(tracked));
    _retiring.add(tracked);
    return operation;
  }

  void _cancelResource(R? resource) {
    try {
      if (resource is LxAsyncResource) {
        (resource as LxAsyncResource).requestCancel();
      }
    } catch (error, stack) {
      _cleanupFailures.add(AsyncError(error, stack));
    }
  }

  void _closeUnattached(R resource) {
    _cancelResource(resource);
    _drainingResources.add(resource);
    late final Future<void> tracked;
    tracked = Future<void>.sync(resource.close)
        .catchError((Object error, StackTrace stack) {
          _cleanupFailures.add(AsyncError(error, stack));
        })
        .whenComplete(() {
          _drainingResources.remove(resource);
          _retiring.remove(tracked);
        });
    _retiring.add(tracked);
  }

  /// Rejects cleanup from work owned by this family before changing state.
  void assertCanClose() {
    if (_drainingResources.any(LxExecutionContext.isExecuting) ||
        _entries.values.any(
          (entry) =>
              entry.resource != null &&
              LxExecutionContext.isExecuting(entry.resource!),
        )) {
      throw StateError('A producer cannot await closure of its own family.');
    }
  }

  @override
  void requestCancel() {
    if (_closing) return;
    _closing = true;
    for (final entry in _entries.values) {
      entry.expiry?.cancel();
      final resource = entry.resource;
      _cancelResource(resource);
    }
  }

  @override
  Future<void> drain() async {
    assertCanClose();
    final errors = <AsyncError>[];
    for (final entry in _entries.values.toList()) {
      try {
        if (entry.refresh != null) await entry.refresh;
      } on LxCancelledException {
        /* Replacement stopped on family closure. */
      } catch (error, stack) {
        errors.add(AsyncError(error, stack));
      }
      final resource = entry.resource;
      if (resource is LxAsyncResource) {
        try {
          await (resource as LxAsyncResource).drain();
        } catch (error, stack) {
          errors.add(AsyncError(error, stack));
        }
      }
    }
    while (_retiring.isNotEmpty) {
      await Future.wait(_retiring.toList());
    }
    if (errors.isNotEmpty) throw LxCleanupException(errors);
  }

  /// Stops admission, drains all producers, and closes all handles. In-flight
  /// cleanup failures are reported after every resource has been attempted.
  Future<void> close() {
    assertCanClose();
    if (_closingFuture != null) return _closingFuture!;
    requestCancel();
    return _closingFuture = () async {
      final errors = <AsyncError>[];
      try {
        await drain();
      } catch (error, stack) {
        errors.add(AsyncError(error, stack));
      }
      for (final entry in _entries.entries.toList().reversed) {
        try {
          await _retire(entry.key, entry.value);
        } catch (_) {
          /* Collected by retirement. */
        }
      }
      // drain awaited earlier retirements; the loop above awaited every
      // remaining entry. Closing prevents any further admission or eviction.
      errors.addAll(_cleanupFailures);
      _disposed = true;
      if (errors.isNotEmpty) throw LxCleanupException(errors);
    }();
  }
}

final class _LxFamilyEntry<T, R extends LxReactive<T>> {
  final LxFamilyHandle<T, R> handle;
  R? resource;
  void Function()? listener;
  void Function(bool)? activity;
  Timer? expiry;
  Future<void>? refresh;
  bool retired = false;
  _LxFamilyEntry(this.handle, this.resource);
}
