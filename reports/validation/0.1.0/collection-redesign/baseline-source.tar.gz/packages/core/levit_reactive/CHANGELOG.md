## 0.1.0

- Coordinate the breaking ownership, refresh and tooling release. Requires Dart
  3.12+ and Flutter 3.44+ where applicable; see MIGRATION_0.1.0.md in the repository.

## 0.0.12

- **Breaking:** reactive `call()` only reads; assign through `.value`.
- Isolate asynchronous batch notification queues by execution context, including nested batches and history middleware.
- Updated internal runtime constraints to `^0.0.12`.

## 0.0.11

- Add `LxStreamCompletionPolicy.close` and `.retain`; `close` remains the
  compatibility default, while `retain` permits explicit source rebinding.
- Add `LxAsyncConcurrency.latest` and `.exhaustLatest` to async computed values
  and workers. `exhaustLatest` runs at most one trailing recomputation.
- Add `LxFamily<K, R>` for lazy keyed reactive resources, explicit
  invalidation, safe diagnostic key formatting, and optional inactivity
  eviction.

## 0.0.10
- Coordinated release version bump.

## 0.0.9
- Coordinated release version bump.

## 0.0.8
- Preserved original stack traces when synchronous `LxComputed` evaluations fail.
- Deprecated the legacy `LevitReactiveBatch.fromChanges` factory.
- Coordinated release version bump.

## 0.0.7
- Bumped version to 0.0.7

## 0.0.6

### Breaking Changes
- **Renamed** `LevitStateMiddlewareChain` to `LevitReactiveMiddlewareChain`.
- Added `isSensitive` property to `LxReactive` interface.

### New Features
- Added `isSensitive` parameter to `lxVar` and `LxReactive` to mark sensitive data (e.g., passwords/tokens) for obfuscation in DevTools/Monitor.

## 0.0.5
- Production-ready documentation (Effective Dart compliance)
- Added `topics` to pubspec for improved discoverability
- Performance and stability improvements

## 0.0.4

- Unified `LevitReactiveMiddleware` architecture.
- Optimized `LxComputed` with batching and smarter dependency tracking.
- Added `LxLxStatus` and improved asynchronous types.
- Fixed memory leaks in deep reactive graphs.
- Performance improvements for large-scale state mutations.

## 0.0.3

- Linting fixes and strict analysis compliance.
- Refactored test coverage for `LxAsyncComputed`.

## 0.0.2

- Added documentation for `LxError`, `LxAsyncComputed`, `LevitReactiveHistoryMiddleware`, `LevitReactiveMiddleware`, and `LevitReactiveNotifier`.
- Fixed lint issues in `core.dart`.
- Added example project.

## 0.0.1

- Initial release.
