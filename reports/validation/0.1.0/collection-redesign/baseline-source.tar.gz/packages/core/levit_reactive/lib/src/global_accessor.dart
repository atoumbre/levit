part of '../levit_reactive.dart';

/// The global entry point for the Levit reactive engine.
///
/// [Lx] provides static access to core functionality, including configuration,
/// dependency tracking, and batching.
class Lx {
  /// The active observer capturing dependencies.
  static LevitReactiveObserver? get proxy => _LevitReactiveCore.proxy;

  /// Sets the active observer.
  static set proxy(LevitReactiveObserver? value) {
    _LevitReactiveCore.proxy = value;
  }

  /// Whether to capture stack traces on state changes (performance intensive).
  static bool get captureStackTrace => _LevitReactiveCore.captureStackTrace;

  static set captureStackTrace(bool value) {
    _LevitReactiveCore.captureStackTrace = value;
  }

  static bool _enableWatchMonitoring = false;

  /// Global flag to enable or disable performance monitoring for all [LxWorker] instances.
  ///
  /// When `true` (default), watchers track execution counts and durations.
  static bool get enableWatchMonitoring => _enableWatchMonitoring;

  static set enableWatchMonitoring(bool value) {
    _enableWatchMonitoring = value;
  }

  /// Registers a new [LevitReactiveMiddleware] to intercept or observe state changes.
  ///
  /// If [token] is provided, registration is unique for that token.
  static LevitReactiveMiddleware addMiddleware(
    LevitReactiveMiddleware middleware, {
    Object? token,
  }) {
    return LevitReactiveMiddleware.add(middleware, token: token);
  }

  /// Unregisters a previously added middleware.
  static bool removeMiddleware(LevitReactiveMiddleware middleware) {
    return LevitReactiveMiddleware.remove(middleware);
  }

  /// Unregisters a middleware by [token].
  static bool removeMiddlewareByToken(Object token) {
    return LevitReactiveMiddleware.removeByToken(token);
  }

  /// Removes all active middlewares.
  static void clearMiddlewares() {
    LevitReactiveMiddleware.clear();
  }

  /// Checks if a particular middleware is currently registered.
  static bool containsMiddleware(LevitReactiveMiddleware middleware) {
    return LevitReactiveMiddleware.contains(middleware);
  }

  /// Checks whether a middleware token is currently registered.
  static bool containsMiddlewareToken(Object token) {
    return LevitReactiveMiddleware.containsToken(token);
  }

  /// Executes [action] while temporarily bypassing all registered middlewares.
  static void runWithoutMiddleware(void Function() action) {
    LevitReactiveMiddleware.runWithoutMiddleware(action);
  }

  /// Executes [callback] in a synchronous batch.
  ///
  /// Notifications for all variables mutated inside the batch are deferred
  /// until the callback completes, ensuring only a single notification per variable.
  static R batch<R>(R Function() callback) {
    return _LevitReactiveCore.batch(callback);
  }

  /// Executes asynchronous [callback] in a batch.
  ///
  /// Notifications are collected in the current execution context across awaits.
  /// Concurrent outer batches flush independently; nested batches merge into an
  /// enclosing open batch. Errors flush changes and close the context.
  /// Values remain shared: outside writes notify immediately, even to a source
  /// touched by a pending batch. This provides no isolation or rollback.
  /// Work escaping the callback uses an enclosing open batch or normal delivery.
  static Future<R> batchAsync<R>(Future<R> Function() callback) {
    return _LevitReactiveCore.batchAsync(callback);
  }

  /// Returns `true` if the current execution context has an open batch.
  static bool get isBatching => _LevitReactiveCore.isBatching;

  /// The context is passed to [LevitReactiveMiddleware.startedListening]
  /// and [LevitReactiveMiddleware.stoppedListening].
  static T runWithContext<T>(LxListenerContext context, T Function() fn) {
    return _LevitReactiveCore.runWithContext(context, fn);
  }

  /// Returns the current active listener context, if any.
  static LxListenerContext? get listenerContext =>
      _LevitReactiveCore.listenerContext;

  /// Executes [fn] while associating any created reactive variables with [ownerId].
  static T runWithOwner<T>(String ownerId, T Function() fn) {
    return _LevitReactiveCore.runWithContext(
      LxListenerContext(type: 'Owner', id: 0, data: {'ownerId': ownerId}),
      fn,
    );
  }

  /// Internal: Enters an asynchronous tracking scope.
  @visibleForTesting
  static void enterAsyncScope() {
    _LevitReactiveCore._enterAsyncScope();
  }

  /// Internal: Exits an asynchronous tracking scope.
  @visibleForTesting
  static void exitAsyncScope() {
    _LevitReactiveCore._exitAsyncScope();
  }

  /// Internal: Zone key for identifying the active async computed tracker.
  @visibleForTesting
  static Object get asyncComputedTrackerZoneKey =>
      _LevitReactiveCore.asyncComputedTrackerZoneKey;
}
