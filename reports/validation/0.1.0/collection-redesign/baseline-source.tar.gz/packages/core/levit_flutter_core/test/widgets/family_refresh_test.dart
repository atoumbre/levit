import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:levit_flutter_core/levit_flutter_core.dart';

void main() {
  testWidgets('mounted direct builder follows the same handle across refresh', (
    tester,
  ) async {
    var generation = 0;
    final family = LxFamily<String, int, LxVar<int>>((_) => (++generation).lx);
    final handle = family('item');
    await tester.pumpWidget(
      MaterialApp(home: LBuilder(handle, (value) => Text('$value'))),
    );
    expect(find.text('1'), findsOneWidget);
    expect(handle.isActive, isTrue);
    await family.refresh('item');
    await tester.pump();
    expect(find.text('2'), findsOneWidget);
    expect(family('item'), same(handle));
    handle.resource.value = 3;
    await tester.pump();
    expect(find.text('3'), findsOneWidget);
    await tester.pumpWidget(const SizedBox.shrink());
    expect(handle.isActive, isFalse);
    await family.close();
  });

  testWidgets('status builder gets retained null during refresh and failure', (
    tester,
  ) async {
    final next = Completer<String?>();
    var builds = 0;
    final family = LxFamily<String, LxStatus<String?>, LxFuture<String?>>(
      (_) => ++builds == 1
          ? LxFuture(Future.value(null))
          : LxFuture(next.future, previous: const LxSuccess<String?>(null)),
    );
    final handle = family('item');
    await handle.resource.wait;
    await tester.pumpWidget(
      MaterialApp(
        home: LStatusBuilder<String?>(
          handle,
          onSuccess: (value) => Text('success:$value'),
          onWaiting: (status) =>
              Text('waiting:${status.hasLastValue}:${status.lastValue}'),
          onError: (status) => Text(
            'error:${status.hasLastValue}:${status.lastValue}:${status.error}',
          ),
        ),
      ),
    );
    expect(find.text('success:null'), findsOneWidget);
    await family.refresh('item');
    await tester.pump();
    expect(find.text('waiting:true:null'), findsOneWidget);
    final failed = expectLater(handle.resource.wait, throwsStateError);
    next.completeError(StateError('offline'));
    await failed;
    await tester.pump();
    expect(find.textContaining('error:true:null'), findsOneWidget);
    await tester.pumpWidget(const SizedBox.shrink());
    await family.close();
  });

  testWidgets('query switch cannot render an obsolete completion', (
    tester,
  ) async {
    final a = Completer<int>();
    final b = Completer<int>();
    final family = LxFamily<String, LxStatus<int>, LxFuture<int>>(
      (key) => LxFuture(key == 'a' ? a.future : b.future),
    );
    final selected = 'a'.lx;
    await tester.pumpWidget(
      MaterialApp(
        home: LWatch(
          () => LStatusBuilder<int>(
            family(selected.value),
            onSuccess: (value) => Text('$value'),
            onWaiting: (_) => const Text('waiting'),
          ),
        ),
      ),
    );
    selected.value = 'b';
    await tester.pump();
    b.complete(2);
    await family('b').resource.wait;
    await tester.pumpAndSettle();
    expect(find.text('2'), findsOneWidget);
    a.complete(1);
    await family('a').resource.wait;
    await tester.pumpAndSettle();
    expect(find.text('2'), findsOneWidget);
    expect(find.text('1'), findsNothing);
    await tester.pumpWidget(const SizedBox.shrink());
    await selected.close();
    await family.close();
  });
}
