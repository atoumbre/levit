part of '../../levit_dart.dart';

/// One task-backed producer inside a query family. Its family owns its lifetime.
class LevitQueryResource<T> extends LxFuture<T> {
  final LevitTaskExecution<T> execution;
  final LevitTaskEngine _engine;
  final void Function(LevitQueryResource<T>) _released;
  DateTime? _succeededAt;
  Future<void>? _queryClose;
  LevitQueryResource._(
    this.execution,
    this._engine,
    this._released,
    DateTime Function() now,
    LxStatus<T>? previous,
  ) : super(execution.result, previous: previous) {
    execution.result.then<void>(
      (_) => _succeededAt = now(),
      onError: (Object _, StackTrace __) {},
    );
  }
  DateTime? get succeededAt => _succeededAt;
  @override
  void requestCancel() {
    execution.cancel();
    super.requestCancel();
  }

  @override
  Future<void> close() {
    final running = _currentTaskZone?.execution;
    if (running?.executionId == execution.executionId) {
      throw StateError('A query cannot close its own producer from its task.');
    }
    return _queryClose ??= () async {
      try {
        await super.close();
        final failures = _engine._cleanupFailures
            .where(
              (failure) =>
                  failure.resource is _TaskExecution &&
                  (failure.resource as _TaskExecution).executionId ==
                      execution.executionId,
            )
            .toList();
        if (failures.isNotEmpty)
          throw LevitDisposalException.aggregate(failures);
      } finally {
        _released(this);
      }
    }();
  }
}

/// Task-backed query state using the same stable handles and retention as
/// [LxFamily]. Repeated reads deduplicate pending work. [fetch] respects freshness;
/// [refresh] forces replacement after a completed request and joins in-flight
/// requests. Reading [call] is observation and does not trigger refresh loops.
///
/// A provided engine is borrowed; the family cancels only its own executions.
/// Otherwise it owns an engine and closes it after draining its query producers.
final class LevitQueryFamily<K, T>
    implements LevitDisposable, LevitDrainable, LevitExecutionBoundary {
  final FutureOr<T> Function(K key, LevitTaskContext context) _load;
  final LevitTaskEngine _engine;
  final bool _ownsEngine;
  final Duration staleTime;
  final LevitRetryPolicy? retryPolicy;
  final TaskCachePolicy<T>? Function(K key)? cachePolicy;
  final DateTime Function() _now;
  late final LxFamily<K, LxStatus<T>, LevitQueryResource<T>> _family;
  final Map<K, Future<void>> _refreshes = {};
  final Set<LevitQueryResource<T>> _resources = Set.identity();
  bool _closing = false;
  Future<void>? _closeFuture;

  LevitQueryFamily(
    this._load, {
    LevitTaskEngine? engine,
    this.staleTime = const Duration(seconds: 30),
    this.retryPolicy,
    this.cachePolicy,
    int maxInactiveEntries = 128,
    Duration gracePeriod = const Duration(seconds: 30),
    String? name,
    String Function(K key)? debugKey,
    DateTime Function()? now,
  }) : _engine = engine ?? LevitTaskEngine(maxConcurrent: 8),
       _ownsEngine = engine == null,
       _now = now ?? DateTime.now {
    if (staleTime.isNegative) throw ArgumentError.value(staleTime, 'staleTime');
    _family = LxFamily(
      _create,
      maxInactiveEntries: maxInactiveEntries,
      gracePeriod: gracePeriod,
      name: name,
      debugKey: debugKey,
    );
  }

  LevitQueryResource<T> _create(K key) {
    final previous = _family.peek(key)?.lastValue;
    final execution = _engine.submit(
      (context) => _load(key, context),
      group: _engine.rootGroup,
      retryPolicy: retryPolicy,
      cachePolicy: cachePolicy?.call(key),
    );
    final resource = LevitQueryResource<T>._(
      execution,
      _engine,
      _resources.remove,
      _now,
      previous,
    );
    _resources.add(resource);
    return resource;
  }

  int get length => _family.length;
  bool get isClosing => _closing;
  bool get isDisposed => _family.isDisposed;
  Iterable<K> get keys => _family.keys;
  LxFamilyHandle<LxStatus<T>, LevitQueryResource<T>> call(K key) =>
      _family(key);
  LxFamilyHandle<LxStatus<T>, LevitQueryResource<T>>? peek(K key) =>
      _family.peek(key);

  bool isFresh(K key) {
    final handle = _family.peek(key);
    if (handle == null || handle.isReplacing || handle.refreshError != null)
      return false;
    final resource = handle.resource;
    final timestamp = resource.succeededAt;
    return timestamp != null &&
        resource.value is LxSuccess<T> &&
        _now().difference(timestamp) < staleTime;
  }

  /// Returns fresh data, deduplicating requests and preserving nullable success.
  Future<T> fetch(K key) async {
    final handle = call(key);
    if (_refreshes[key] case final pending?) {
      await pending;
    } else if (!isFresh(key)) {
      await refresh(key);
    }
    return await handle.resource.wait;
  }

  /// Joins an already running load/refresh. Otherwise cancels and drains the old
  /// producer before replacing it, retaining previous data through waiting/error.
  Future<void> refresh(K key) {
    assertCanDispose();
    if (_closing) throw StateError('Query family is closing.');
    final pending = _refreshes[key];
    if (pending != null) return pending;
    final existing = _family.peek(key);
    final handle = existing ?? _family(key);
    final complete = Completer<void>();
    _refreshes[key] = complete.future;
    complete.future.ignore();
    unawaited(() async {
      try {
        if (existing != null &&
            !handle.isReplacing &&
            (handle.refreshError != null || !handle.resource.isWaiting)) {
          await _family.refresh(key);
        }
        if (_closing) throw const LxCancelledException();
        await handle.resource.wait;
        complete.complete();
      } catch (error, stack) {
        complete.completeError(error, stack);
      } finally {
        _refreshes.remove(key);
      }
    }());
    return complete.future;
  }

  Future<bool> invalidate(K key) async {
    assertCanDispose();
    if (_closing) throw StateError('Query family is closing.');
    final handle = _family.peek(key);
    if (handle == null) return false;
    if (handle.isActive) {
      await refresh(key);
      return true;
    }
    return _family.evict(key);
  }

  Future<bool> evict(K key) {
    assertCanDispose();
    return _family.evict(key);
  }

  @override
  void assertCanDispose() {
    final running = _currentTaskZone?.execution;
    if (running != null &&
        _resources.any(
          (resource) => resource.execution.executionId == running.executionId,
        )) {
      throw StateError(
        'A query task cannot dispose or refresh its own family.',
      );
    }
    _family.assertCanClose();
  }

  @override
  void requestCancel() {
    if (_closing) return;
    _closing = true;
    _family.requestCancel();
    if (_ownsEngine) _engine.requestCancel();
  }

  @override
  Future<void> drain() async {
    assertCanDispose();
    await _family.drain();
    await Future.wait(
      _refreshes.values.toList().map(
        (future) =>
            future.then<void>((_) {}, onError: (Object _, StackTrace __) {}),
      ),
    );
  }

  @override
  Future<void> dispose() {
    assertCanDispose();
    requestCancel();
    return _closeFuture ??= () async {
      // Capture admitted refresh callers before producer closure settles them.
      final refreshes = [
        for (final future in _refreshes.values)
          future.then<void>((_) {}, onError: (Object _, StackTrace __) {}),
      ];
      final failures = <LevitDisposalFailure>[];
      try {
        await _family.close();
      } catch (error, stack) {
        failures.add(
          LevitDisposalFailure(
            resource: _family,
            error: error,
            stackTrace: stack,
          ),
        );
      }
      if (_ownsEngine) {
        try {
          await _engine.dispose();
        } catch (error, stack) {
          failures.add(
            LevitDisposalFailure(
              resource: _engine,
              error: error,
              stackTrace: stack,
            ),
          );
        }
      }
      await Future.wait(refreshes);
      if (failures.isNotEmpty) throw LevitDisposalException.aggregate(failures);
    }();
  }
}
