part of '../../levit_monitor.dart';

/// A transport that writes [MonitorEvent]s to a file.
class FileTransport implements LevitTransport {
  final File _file;
  late final IOSink _sink;

  /// Creates a new [FileTransport] writing to [filePath].
  FileTransport(String filePath) : _file = File(filePath) {
    _sink = _file.openWrite(mode: FileMode.append);
  }

  @override
  Stream<void> get onConnect => const Stream<void>.empty();

  @override
  void send(MonitorEvent event) {
    final category = switch (event) {
      ReactiveEvent _ ||
      ReactiveBatchEvent _ ||
      ReactiveErrorEvent _ =>
        'state',
      DependencyEvent _ => 'di',
      SnapshotEvent _ => 'snapshot',
      LogEvent _ => 'log',
      CustomMonitorEvent _ => 'custom',
    };

    _sink.writeln(jsonEncode({
      'category': category,
      ...event.toJson(),
    }));
  }

  @override
  Future<void> close() async {
    await _sink.flush();
    await _sink.close();
  }
}
