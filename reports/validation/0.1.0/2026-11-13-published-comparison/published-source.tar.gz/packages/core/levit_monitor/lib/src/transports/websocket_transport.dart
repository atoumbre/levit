part of '../../levit_monitor.dart';

/// A transport that sends [MonitorEvent]s via WebSocket.
class WebSocketTransport implements LevitTransport {
  /// The WebSocket channel for communication.
  WebSocketChannel? _channel;

  /// Whether the user has explicitly closed the transport.
  bool _isDisposed = false;

  // These fields are set only for self-managed connections.
  final String? _url;
  final String? _appId;
  final WebSocketChannel Function(Uri uri)? _channelBuilder;
  final void Function(WebSocketTransport)? _onReady;
  final void Function(Object)? _onError;

  // Reconnect backoff state.
  Timer? _reconnectTimer;
  int _retryAttempts = 0;

  final _onConnectController = StreamController<void>.broadcast();

  @override
  Stream<void> get onConnect => _onConnectController.stream;

  /// Creates a [WebSocketTransport] from an existing [WebSocketChannel].
  WebSocketTransport(WebSocketChannel channel)
      : _url = null,
        _appId = null,
        _channelBuilder = null,
        _onReady = null,
        _onError = null {
    _channel = channel;
    _listenToChannel(channel);
  }

  WebSocketTransport._(
    this._url,
    this._appId,
    this._channelBuilder,
    this._onReady,
    this._onError,
  ) {
    _connect();
  }

  /// Connects to a server at the given URL.
  static WebSocketTransport connect(
    String serverUrl, {
    String? appId,
    WebSocketChannel Function(Uri uri)? channelBuilder,
    void Function(WebSocketTransport)? onReady,
    void Function(Object)? onError,
  }) {
    return WebSocketTransport._(
      serverUrl,
      appId,
      channelBuilder,
      onReady,
      onError,
    );
  }

  void _connect() {
    if (_isDisposed) return;

    try {
      var uri = Uri.parse(_url!);
      final queryParams = Map<String, dynamic>.from(uri.queryParameters);
      if (_appId != null) {
        queryParams['appId'] = _appId!;
      }
      uri = uri.replace(queryParameters: queryParams);

      _channel = _channelBuilder?.call(uri) ?? WebSocketChannel.connect(uri);
      _channel!.ready.then((_) {
        _onReady?.call(this);
      }).catchError((e) {
        _onError?.call(e);
      });
      _listenToChannel(_channel!);
    } catch (e) {
      _onError?.call(e);
      _scheduleReconnect();
    }
  }

  void _listenToChannel(WebSocketChannel channel) {
    _reconnectTimer?.cancel();
    _reconnectTimer = null;
    _retryAttempts = 0;

    channel.stream.listen(
      (_) {
        // Incoming payloads are handled by downstream monitor consumers.
      },
      onDone: _handleDisconnect,
      onError: (_) => _handleDisconnect(),
      cancelOnError: true,
    );
    // A successful listen subscription marks this transport as connected.
    if (!_onConnectController.isClosed) {
      _onConnectController.add(null);
    }
  }

  void _handleDisconnect() {
    _channel = null;
    if (!_isDisposed && _url != null) {
      _scheduleReconnect();
    }
  }

  void _scheduleReconnect() {
    if (_isDisposed || (_reconnectTimer?.isActive ?? false)) return;

    final delaySeconds = (1 << _retryAttempts).clamp(1, 32);
    final delay = Duration(seconds: delaySeconds);

    _retryAttempts++;
    _reconnectTimer = Timer(delay, _connect);
  }

  void _send(Map<String, dynamic> data) {
    if (_isDisposed) return;
    if (_channel == null) return;
    try {
      _channel!.sink.add(jsonEncode(data));
    } catch (_) {
      _handleDisconnect();
    }
  }

  @override
  void send(MonitorEvent event) {
    final category = switch (event) {
      ReactiveEvent _ ||
      ReactiveBatchEvent _ ||
      ReactiveErrorEvent _ =>
        'state',
      DependencyEvent _ => 'di',
      SnapshotEvent _ => 'snapshot',
      LogEvent _ => 'log',
      CustomMonitorEvent _ => 'custom',
    };

    _send({
      'category': category,
      ...event.toJson(),
    });
  }

  @override
  Future<void> close() async {
    if (_isDisposed) return;
    _isDisposed = true;
    _reconnectTimer?.cancel();
    try {
      await _channel?.sink.close();
    } catch (_) {}
    _channel = null;
    try {
      await _onConnectController.close();
    } catch (_) {}
  }
}
