# Changelog

## 0.0.11

- **Breaking:** task callbacks now receive `LevitTaskContext`; isolate work uses
  the dedicated `scheduleIsolate`, `submitIsolate`, and `runIsolateTask` APIs.
- Expand `LevitTaskEngine`, `LevitTasksMixin`, and
  `LevitReactiveTasksMixin` instead of adding a parallel action abstraction.
- Add named logical task IDs with `reject` (default), `join`, `drop`, `restart`,
  `enqueue`, and `coalesceLatest` conflict policies.
- Add cooperative cancellation, validated progress, execution handles, isolate
  progress/cancellation bridging, retries, and per-execution metadata.
- Add dependency-neutral structured task events, global
  `LevitTaskMiddleware`, and opt-in `LevitTaskTracker`.
- Add reactive category/blocking selectors and execution-ID protection against
  stale completion publication.
- Make task engines controller-owned and await their lifecycle cleanup.
- Updated internal package constraints to `^0.0.11`.

## 0.0.10
- `LevitTasksMixin.tasksEngine` lazy-inits before `onInit` and throws a clear error after `onClose`.
- `LevitReactiveTasksMixin` lazily initializes `isBusy` and `totalProgress`; clear error after close.
- Coordinated release version bump.
- Updated internal package constraints to `^0.0.10`.

## 0.0.9
- Coordinated release version bump.
- Updated internal package constraints to `^0.0.9`.


## 0.0.8
- Refactored task-engine support code into smaller internal modules without changing the public API.
- Coordinated release version bump.
- Updated internal package constraints to `^0.0.8`.

## 0.0.7
- Bumped version to 0.0.7

## 0.0.6

### Breaking Changes
- **Renamed Mixins**:
    - `LevitExecutionLoopMixin` -> `LevitLoopExecutionMixin`
- **FEAT**: Added `startIsolateLoop` to `LevitLoopExecutionMixin` for running background tasks in separate isolates.

## 0.0.5
- Production-ready documentation (Effective Dart compliance)
- Added `topics` to pubspec for improved discoverability
- Task management mixins with priority queuing
- Retry logic with exponential backoff
- Isolate task execution support

## 0.0.4
- Initial release
