import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:levit_flutter_core/levit_flutter_core.dart';

void main() {
  testWidgets('LAsyncView error handling and build helpers', (tester) async {
    await tester.pumpWidget(MaterialApp(
        home: LAsyncView<String>(
            resolver: (context) async => throw Exception('View Error'),
            builder: (context, value) => Text(value),
            error: (context, err) => Text('Custom Error: $err'))));
    await tester.pumpAndSettle();
    expect(find.textContaining('Custom Error'), findsOneWidget);
  });
}
