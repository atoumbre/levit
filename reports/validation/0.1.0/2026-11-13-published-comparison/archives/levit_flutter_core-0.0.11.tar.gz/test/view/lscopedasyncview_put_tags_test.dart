import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:levit_flutter_core/levit_flutter_core.dart';
import '../helpers.dart';

void main() {
  testWidgets('LScopedAsyncView.put works with tags', (tester) async {
    Levit.reset(force: true);
    await tester.pumpWidget(MaterialApp(
        home: LScopedAsyncView<TestController>.put(() async {
      await Future.delayed(const Duration(milliseconds: 10));
      return TestController()..count = 42;
    },
            tag: 'async-scoped',
            loading: (_) => const Text('Loading...'),
            builder: (context, controller) =>
                Text('Count: ${controller.count}'))));
    expect(find.text('Loading...'), findsOneWidget);
    await tester.pumpAndSettle();
    expect(find.text('Count: 42'), findsOneWidget);
  });
}
