import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:levit_flutter_core/levit_flutter_core.dart';
import '../helpers.dart';

void main() {
  testWidgets('LScope.lazyPutAsync static factory', (tester) async {
    await tester.pumpWidget(LScope.lazyPutAsync<TestController>(() async {
      await Future.delayed(const Duration(milliseconds: 10));
      return TestController()..count = 789;
    },
        child: MaterialApp(
            home: LAsyncView<TestController>(
                builder: (context, controller) =>
                    Text('Count: ${controller.count}')))));
    await tester.pumpAndSettle();
    expect(find.text('Count: 789'), findsOneWidget);
  });
}
