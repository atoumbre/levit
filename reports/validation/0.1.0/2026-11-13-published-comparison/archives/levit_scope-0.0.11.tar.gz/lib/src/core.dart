part of '../levit_scope.dart';

/// An interface for objects that participate in the [LevitScope] lifecycle.
///
/// Implement this interface to receive callbacks for initialization and disposal.
/// This mechanism ensures deterministic cleanup when the owning scope is disposed.
///
/// // Example usage:
/// ```dart
/// class MyService implements LevitScopeDisposable {
///   @override
///   void onInit() {
///     print('Service initialized');
///   }
///
///   @override
///   void onClose() {
///     print('Service disposed');
///   }
/// }
/// ```
abstract class LevitScopeDisposable {
  /// Creates a [LevitScopeDisposable].
  const LevitScopeDisposable();

  /// Called immediately after the object is instantiated.
  ///
  /// Use this method for isolated initialization logic, such as setting up
  /// internal state or starting independent listeners. This runs before the
  /// object is returned to the caller.
  void onInit() {}

  /// Called when the object is attached to a [LevitScope].
  ///
  /// This occurs after [onInit]. Use this callback if your initialization
  /// logic requires access to the scope itself or the registration [key].
  ///
  /// [scope] is the [LevitScope] that manages this object.
  /// [key] is the unique registration key associated with this instance.
  void didAttachToScope(LevitScope scope, {String? key}) {}

  /// Called when the object is removed from the scope or the scope is disposed.
  ///
  /// Use this method to release resources, close streams, or cancel timers.
  FutureOr<void> onClose() {}
}

/// A resource with an explicit, optionally asynchronous disposal operation.
///
/// Unlike [LevitScopeDisposable], this contract has no initialization hooks.
/// A directly registered instance implementing this interface is owned by its
/// registration scope and disposed when that registration is removed.
abstract interface class LevitDisposable {
  /// Releases resources held by this object.
  FutureOr<void> dispose();
}

/// One failure captured while a scope or resource owner was being disposed.
final class LevitDisposalFailure {
  /// The resource whose cleanup failed.
  final Object resource;

  /// The error thrown by the resource.
  final Object error;

  /// The associated stack trace.
  final StackTrace stackTrace;

  /// Creates a disposal failure record.
  const LevitDisposalFailure({
    required this.resource,
    required this.error,
    required this.stackTrace,
  });

  @override
  String toString() => 'LevitDisposalFailure(${resource.runtimeType}: $error)';
}

/// Aggregate error thrown after best-effort disposal has finished.
///
/// Cleanup always continues after an individual failure. Callers receive this
/// exception only after every selected resource has been given a chance to
/// close.
final class LevitDisposalException implements Exception {
  /// All failures in deterministic disposal order.
  final List<LevitDisposalFailure> failures;

  /// Creates an aggregate disposal error.
  LevitDisposalException(Iterable<LevitDisposalFailure> failures)
      : failures = List<LevitDisposalFailure>.unmodifiable(failures);

  @override
  String toString() =>
      'LevitDisposalException(${failures.length} cleanup failure'
      '${failures.length == 1 ? '' : 's'})';
}

/// Metadata container for a dependency registered within a [LevitScope].
///
/// This class tracks the lifecycle state, creation strategy, and persistence
/// settings for a specific registration.
class LevitDependency<S> {
  /// The resolved instance, or `null` if not yet instantiated.
  S? instance;

  /// The synchronous builder function for lazy or factory instantiation.
  final S Function()? builder;

  /// The asynchronous builder function for async instantiation.
  final Future<S> Function()? asyncBuilder;

  /// Whether the registration persists across a non-forced [LevitScope.reset].
  ///
  /// [LevitScope.dispose] always calls [LevitScope.reset] with `force: true`,
  /// so permanent dependencies do not survive disposed scopes (including
  /// unmounted [LScope] widgets and typical widget-test tear-down). Prefer
  /// `permanent: true` on root / long-lived scopes; on short-lived page scopes
  /// it does not extend lifetime past widget unmount.
  final bool permanent;

  /// Whether the instance creation is deferred until the first lookup.
  final bool isLazy;

  /// Whether a new instance is created for every lookup.
  final bool isFactory;

  /// Whether the [instance] has been created and is currently active.
  bool get isInstantiated => instance != null;

  /// Whether this registration uses an asynchronous builder.
  bool get isAsync => asyncBuilder != null;

  /// Creates metadata for a dependency registration.
  LevitDependency({
    this.instance,
    this.builder,
    this.asyncBuilder,
    this.permanent = false,
    this.isLazy = false,
    this.isFactory = false,
  });
}

/// Typed key for dependency registrations.
///
/// This avoids relying on `Type.toString()` (or `S.toString()`) for identity,
/// which can change under obfuscation/minification. String representations are
/// kept for debugging/middleware only.
class LevitScopeKey {
  static final Map<Type, String> _debugTypeCache = {};

  final Type type;
  final String? tag;

  const LevitScopeKey(this.type, this.tag);

  static LevitScopeKey of<S>({String? tag}) => LevitScopeKey(S, tag);

  String get debugString {
    final typeString = _debugTypeCache[type] ??= type.toString();
    if (tag == null) return typeString;
    // Preserve historical format: Type_tag
    return '${typeString}_$tag';
  }

  @override
  String toString() => debugString;

  @override
  bool operator ==(Object other) =>
      other is LevitScopeKey && other.type == type && other.tag == tag;

  @override
  int get hashCode => Object.hash(type, tag);
}

/// A hierarchical dependency injection container.
///
/// [LevitScope] manages the lifecycle of dependencies, supports hierarchical
/// scoping, and allows for deterministic cleanup.
///
/// ## Resolution Rules
/// 1.  **Local Check**: Searches the current scope's registry first.
/// 2.  **Parent Delegation**: If not found locally, recursively searches parent scopes.
/// 3.  **Isolation**: Dependencies registered in a child scope are not visible to parents.
///
/// ## Lifecycle
/// When a scope is disposed via [dispose]:
/// *   All locally registered dependencies implementing [LevitScopeDisposable]
///     will receive a [LevitScopeDisposable.onClose] callback.
/// *   The scope becomes unusable and should be discarded.
class LevitScope {
  /// Internal counter for unique scope IDs.
  static int _nextId = 0;

  /// The unique identifier for this scope.
  final int id;

  /// A descriptive name for debugging.
  final String name;

  /// The parent scope, or `null` if this is the root scope.
  final LevitScope? _parentScope;

  /// The local registry of dependencies (Key -> Metadata).
  final Map<LevitScopeKey, LevitDependency> _registry = {};

  /// Fast-path registry for tag-less lookups (Type -> Metadata).
  final Map<Type, LevitDependency> _typeRegistry = {};

  /// Ultra-fast instance cache for tag-less singletons.
  final Map<Type, dynamic> _instanceCache = {};

  /// Cache for resolved keys to speed up parent scope lookups.
  final Map<LevitScopeKey, LevitScope> _resolutionCache = {};

  /// Fast-path cache for tag-less parent scope lookups.
  final Map<Type, LevitScope> _typeResolutionCache = {};

  /// Non-owning local aliases (alias key -> canonical local key).
  final Map<LevitScopeKey, LevitScopeKey> _aliases = {};

  /// Reverse alias index used to invalidate aliases with their canonical key.
  final Map<LevitScopeKey, Set<LevitScopeKey>> _aliasesByCanonical = {};

  Future<void>? _disposeFuture;
  bool _isClosing = false;
  bool _isDisposed = false;

  /// Whether terminal scope disposal has started.
  bool get isClosing => _isClosing;

  /// Whether terminal scope disposal has completed.
  bool get isDisposed => _isDisposed;

  /// Completes when terminal disposal completes, or immediately while active.
  Future<void> get disposed => _disposeFuture ?? Future<void>.value();

  /// Creates a new [LevitScope].
  LevitScope._(this.name, {LevitScope? parentScope})
      : id = _nextId++,
        _parentScope = parentScope {
    _notifyScopeCreate();
  }

  /// Creates a new root [LevitScope].
  ///
  /// The root scope has no parent and typically lives for the duration of the app.
  ///
  /// [name] defaults to `'root'` if not provided.
  factory LevitScope.root([String? name]) => LevitScope._(name ?? 'root');

  /// Immediately instantiates and registers a dependency.
  ///
  /// The [builder] is called immediately. If a dependency of type [S] with the
  /// same [tag] already exists, it is replaced (disposed) before the new one is created.
  ///
  /// // Example usage:
  /// ```dart
  /// scope.put(() => AuthService());
  /// ```
  ///
  /// Use [permanent] to survive a *non-forced* [reset] only.
  /// [dispose] always resets with `force: true`, so permanents do not leak
  /// across disposed scopes. Prefer permanent on root / long-lived scopes.
  ///
  /// Returns the created instance.
  S put<S>(S Function() builder, {String? tag, bool permanent = false}) {
    _ensureUsable();
    final key = _getKey<S>(tag);
    final keyString = key.debugString;

    if (_registry.containsKey(key) || _aliases.containsKey(key)) {
      throw StateError(
        'LevitScope($name): "$keyString" is already registered. '
        'Await delete<$S>(tag: ${tag == null ? 'null' : "'$tag'"}, force: true) '
        'before registering a replacement.',
      );
    }

    final info = LevitDependency<S>(permanent: permanent);

    // Instance creation happens before registration so middleware sees final metadata.
    info.instance = _createInstance<S>(builder, keyString, info);

    _registerBinding(key, keyString, info, 'put', tag: tag);

    _initializeInstance(info.instance, keyString, info);

    return info.instance as S;
  }

  /// Registers a dependency to be lazily instantiated.
  ///
  /// The [builder] is only executed when the dependency is first requested via [find].
  ///
  /// If [isFactory] is `true`, a new instance will be created for *every* request.
  /// Otherwise (default), the instance is cached and treated as a singleton within this scope.
  ///
  /// Use [permanent] to survive a *non-forced* [reset] only.
  /// [dispose] always resets with `force: true`. Prefer permanent on root /
  /// long-lived scopes.
  void lazyPut<S>(S Function() builder,
      {String? tag, bool permanent = false, bool isFactory = false}) {
    _ensureUsable();
    final key = _getKey<S>(tag);
    final keyString = key.debugString;

    if (_aliases.containsKey(key)) {
      throw StateError(
        'LevitScope($name): "$keyString" is already registered as an alias.',
      );
    }
    if (!isFactory &&
        _registry.containsKey(key) &&
        _registry[key]!.isInstantiated) {
      return;
    }

    final info = LevitDependency<S>(
      builder: builder,
      permanent: permanent || isFactory,
      isLazy: true,
      isFactory: isFactory,
    );

    _registerBinding(
      key,
      keyString,
      info,
      isFactory ? 'putFactory' : 'lazyPut',
      tag: tag,
    );
  }

  /// Registers an asynchronous dependency to be lazily instantiated.
  ///
  /// The [builder] is only executed when the dependency is first requested via [findAsync].
  ///
  /// If [isFactory] is `true`, the builder is called for *every* request.
  /// Otherwise, the result is cached.
  ///
  /// Use [permanent] to survive a *non-forced* [reset] only.
  /// [dispose] always resets with `force: true`. Prefer permanent on root /
  /// long-lived scopes.
  ///
  /// Returns a function that allows retrieving the dependency (shortcut for `findAsync`).
  Future<S> Function() lazyPutAsync<S>(
    Future<S> Function() builder, {
    String? tag,
    bool permanent = false,
    bool isFactory = false,
  }) {
    _ensureUsable();
    final key = _getKey<S>(tag);
    final keyString = key.debugString;

    if (_aliases.containsKey(key)) {
      throw StateError(
        'LevitScope($name): "$keyString" is already registered as an alias.',
      );
    }
    if (!isFactory &&
        _registry.containsKey(key) &&
        _registry[key]!.isInstantiated) {
      return () => findAsync<S>(tag: tag);
    }

    final info = LevitDependency<S>(
      asyncBuilder: builder,
      permanent: permanent || isFactory,
      isLazy: true,
      isFactory: isFactory,
    );

    _registerBinding(
      key,
      keyString,
      info,
      isFactory ? 'putFactoryAsync' : 'lazyPutAsync',
      tag: tag,
    );

    return () => findAsync<S>(tag: tag);
  }

  /// Binds [Alias] to an existing local singleton registration of [Concrete].
  ///
  /// The alias is non-owning: resolving it returns the canonical instance,
  /// deleting it does not dispose that instance, and disposing the canonical
  /// registration removes all of its aliases before disposing it once.
  ///
  /// Aliases are intentionally local and cannot target factory registrations.
  void bindExisting<Alias, Concrete extends Alias>({
    String? sourceTag,
    String? tag,
  }) {
    _ensureUsable();

    final aliasKey = _getKey<Alias>(tag);
    final canonicalKey = _getKey<Concrete>(sourceTag);
    final canonical = _registry[canonicalKey];

    if (canonical == null) {
      throw StateError(
        'LevitScope($name): Cannot bind alias "${aliasKey.debugString}" '
        'because local source "${canonicalKey.debugString}" is not registered.',
      );
    }
    if (canonical.isFactory) {
      throw StateError(
        'LevitScope($name): Factory registration '
        '"${canonicalKey.debugString}" cannot be aliased.',
      );
    }
    if (aliasKey == canonicalKey) {
      throw ArgumentError(
        'Alias and canonical registration must use different keys.',
      );
    }
    if (_registry.containsKey(aliasKey) || _aliases.containsKey(aliasKey)) {
      throw StateError(
        'LevitScope($name): Alias key "${aliasKey.debugString}" is already '
        'registered.',
      );
    }

    _aliases[aliasKey] = canonicalKey;
    (_aliasesByCanonical[canonicalKey] ??= <LevitScopeKey>{}).add(aliasKey);
    _invalidateLookupCaches(aliasKey);
    _notifyRegister(aliasKey.debugString, canonical, 'bindExisting');
  }

  void _registerBinding<S>(
    LevitScopeKey key,
    String keyString,
    LevitDependency<S> info,
    String source, {
    String? tag,
  }) {
    if (_registry.containsKey(key)) {
      if (info.isLazy || info.isFactory) {}
    }

    _registry[key] = info;

    // Tag-less bindings are mirrored in type registries for O(1) lookups.
    if (tag == null) {
      _typeRegistry[S] = info;
      _typeResolutionCache.remove(S);
    }

    if (_resolutionCache.isNotEmpty) {
      _resolutionCache.remove(key);
    }

    _notifyRegister(keyString, info, source);
  }

  /// Finds and returns a registered instance of type [S].
  ///
  /// This method performs a hierarchical lookup:
  /// 1.  **Local Check**: Checks the current scope.
  /// 2.  **Parent Check**: Recursively checks parent scopes.
  ///
  /// If the dependency is found but not yet instantiated (lazy), it will be created.
  ///
  /// Throws an [Exception] if [S] is not registered in this scope or any ancestor.
  S find<S>({String? tag}) {
    _ensureUsable();
    // Tag-less singleton lookups use a direct instance cache.
    if (tag == null) {
      final cached = _instanceCache[S];
      if (cached != null) {
        return cached as S;
      }

      // Type registry is the primary lookup path for untagged dependencies.
      final info = _typeRegistry[S];
      if (info != null) {
        // Reuse existing singleton and seed instance cache.
        final instance = info.instance;
        if (instance != null && !info.isFactory) {
          _instanceCache[S] = instance;
          return instance as S;
        }
        // Lazy registrations instantiate on first resolve.
        final result = _findLocal<S>(
          info as LevitDependency<S>,
          LevitScopeKey.of<S>().debugString,
          null,
        );
        // Factories must never be cached.
        if (!info.isFactory && info.instance != null) {
          _instanceCache[S] = info.instance;
        }
        return result;
      }

      final aliasKey = LevitScopeKey.of<S>();
      final canonicalKey = _aliases[aliasKey];
      if (canonicalKey != null) {
        final result = _findAliasLocal<S>(
          aliasKey: aliasKey,
          canonicalKey: canonicalKey,
        );
        _instanceCache[S] = result;
        return result;
      }

      // Parent resolution cache avoids repeated ancestor traversal.
      final cachedScope = _typeResolutionCache[S];
      if (cachedScope != null) {
        try {
          return cachedScope.find<S>();
        } catch (_) {
          _typeResolutionCache.remove(S);
        }
      }

      // Parent fallback preserves scope hierarchy resolution.
      if (_parentScope != null) {
        try {
          final instance = _parentScope!.find<S>();
          _typeResolutionCache[S] = _parentScope!;
          return instance;
        } catch (_) {
          // Cached parent may be stale after resets; fall through.
        }
      }

      throw Exception(
        'LevitScope($name): Type "$S" is not registered.\n'
        'Not found in scope or any parent.',
      );
    }

    // Tagged lookups use composite key registries.
    final key = _getKey<S>(tag);
    final keyString = key.debugString;

    final info = _registry[key];
    if (info != null) {
      return _findLocal<S>(info as LevitDependency<S>, keyString, tag);
    }

    final canonicalKey = _aliases[key];
    if (canonicalKey != null) {
      return _findAliasLocal<S>(
        aliasKey: key,
        canonicalKey: canonicalKey,
      );
    }

    // Reuse cached ancestor that previously resolved this key.
    final cachedScope = _readCachedScope(key);
    if (cachedScope != null) {
      try {
        return cachedScope.find<S>(tag: tag);
      } catch (_) {
        _resolutionCache.remove(key);
      }
    }

    // Fallback to parent scope chain.
    if (_parentScope != null) {
      try {
        final instance = _parentScope!.find<S>(tag: tag);
        _cacheScope(key, _parentScope!);
        return instance;
      } catch (_) {
        // Cached ancestry may be invalidated by parent resets.
      }
    }

    throw Exception(
      'LevitScope($name): Type "$S" with tag "$tag" is not registered.\n'
      'Not found in scope or any parent.',
    );
  }

  /// Finds and returns a registered instance of type [S], or `null` if not found.
  ///
  /// Mirrors the behavior of [find] but returns `null` instead of throwing an exception
  /// if the dependency is missing.
  S? findOrNull<S>({String? tag}) {
    _ensureUsable();
    final key = _getKey<S>(tag);
    final keyString = key.debugString;

    // Resolution order matches `find`: local, cached ancestor, then parent.
    final info = _registry[key];
    if (info != null) {
      try {
        return _findLocal<S>(info as LevitDependency<S>, keyString, tag);
      } catch (_) {
        return null;
      }
    }

    final canonicalKey = _aliases[key];
    if (canonicalKey != null) {
      try {
        return _findAliasLocal<S>(
          aliasKey: key,
          canonicalKey: canonicalKey,
        );
      } catch (_) {
        return null;
      }
    }

    final cachedScope = _readCachedScope(key);
    if (cachedScope != null) {
      final instance = cachedScope.findOrNull<S>(tag: tag);
      if (instance != null) {
        return instance;
      }
      _resolutionCache.remove(key);
    }

    if (_parentScope != null) {
      final instance = _parentScope!.findOrNull<S>(tag: tag);
      if (instance != null) {
        _cacheScope(key, _parentScope!);
        return instance;
      }
    }

    return null;
  }

  /// Finds and returns an asynchronously registered instance of type [S].
  ///
  /// Use this for dependencies registered via [lazyPutAsync].
  ///
  /// Throws an [Exception] if [S] is not registered.
  Future<S> findAsync<S>({String? tag}) async {
    _ensureUsable();
    final key = _getKey<S>(tag);
    final keyString = key.debugString;

    // Async lookup follows the same local/cache/parent search order.
    final info = _registry[key];
    if (info != null) {
      return _findLocalAsync<S>(
          info as LevitDependency<S>, key, keyString, tag);
    }

    final canonicalKey = _aliases[key];
    if (canonicalKey != null) {
      return _findAliasLocalAsync<S>(
        aliasKey: key,
        canonicalKey: canonicalKey,
      );
    }

    final cachedScope = _readCachedScope(key);
    if (cachedScope != null) {
      try {
        return await cachedScope.findAsync<S>(tag: tag);
      } catch (_) {
        _resolutionCache.remove(key);
      }
    }

    if (_parentScope != null) {
      try {
        final instance = await _parentScope!.findAsync<S>(tag: tag);
        _cacheScope(key, _parentScope!);
        return instance;
      } catch (_) {}
    }

    throw Exception(
      'LevitScope($name): Type "$S"${tag != null ? ' with tag "$tag"' : ''} is not registered.\n'
      'Not found in scope or any parent.',
    );
  }

  /// Asynchronously finds an instance of type [S], or returns `null` if not found.
  Future<S?> findOrNullAsync<S>({String? tag}) async {
    _ensureUsable();
    final key = _getKey<S>(tag);
    final keyString = key.debugString;

    // Nullable async lookup follows the same search order as `findAsync`.
    final info = _registry[key];
    if (info != null) {
      return _findLocalAsync<S>(
          info as LevitDependency<S>, key, keyString, tag);
    }

    final canonicalKey = _aliases[key];
    if (canonicalKey != null) {
      try {
        return await _findAliasLocalAsync<S>(
          aliasKey: key,
          canonicalKey: canonicalKey,
        );
      } catch (_) {
        return null;
      }
    }

    final cachedScope = _readCachedScope(key);
    if (cachedScope != null) {
      try {
        return await cachedScope.findOrNullAsync<S>(tag: tag);
      } catch (_) {
        _resolutionCache.remove(key);
      }
    }

    if (_parentScope != null) {
      final instance = await _parentScope!.findOrNullAsync<S>(tag: tag);
      if (instance != null) {
        _cacheScope(key, _parentScope!);
        return instance;
      }
    }

    return null;
  }

  LevitScope? _readCachedScope(LevitScopeKey key) {
    final cachedScope = _resolutionCache[key];
    if (cachedScope == null) return null;

    // Tagged lookup caches are only valid when they point to an ancestor.
    if (!_isAncestorScope(cachedScope)) {
      _resolutionCache.remove(key);
      return null;
    }

    return cachedScope;
  }

  bool _isAncestorScope(LevitScope candidate) {
    LevitScope? current = _parentScope;
    while (current != null) {
      if (identical(current, candidate)) {
        return true;
      }
      current = current._parentScope;
    }
    return false;
  }

  void _cacheScope(LevitScopeKey key, LevitScope scope) {
    if (_resolutionCache.containsKey(key)) {
      _resolutionCache[key] = scope;
    } else {
      // Bound cache growth for high-cardinality tag usage.
      if (_resolutionCache.length > 500) {
        // Full purge is safe; it only affects lookup speed until cache warms.
        _resolutionCache.clear();
      }
      _resolutionCache[key] = scope;
    }
  }

  // In-flight async singleton initializations keyed by dependency key.
  final Map<LevitScopeKey, Future<dynamic>> _pendingInit = {};

  Future<S> _findLocalAsync<S>(LevitDependency<S> info, LevitScopeKey key,
      String keyString, String? tag) async {
    if (info.isInstantiated) {
      return info.instance as S;
    }

    // Factories always create a fresh instance.
    if (info.isFactory && info.isAsync) {
      final instance =
          await _createInstanceAsync<S>(info.asyncBuilder!, keyString, info);
      _initializeInstance(instance, keyString, info);
      _notifyResolve(keyString, info, 'findAsync');
      return instance;
    }

    // `findAsync` supports sync factories for API parity.
    if (info.isFactory && info.builder != null) {
      final instance = _createInstance<S>(info.builder!, keyString, info);
      _initializeInstance(instance, keyString, info);
      _notifyResolve(keyString, info, 'findAsync');
      return instance;
    }

    // Concurrent async resolves share one initializer future per key.
    if (info.isLazy && info.isAsync) {
      if (_pendingInit.containsKey(key)) {
        return await _pendingInit[key] as S;
      }

      final future = (() async {
        try {
          final instance = await _createInstanceAsync<S>(
              info.asyncBuilder!, keyString, info);
          if (!identical(_registry[key], info)) {
            if (instance != null) {
              await _disposeInstance(instance);
            }
            throw StateError(
              'LevitScope($name): Dependency "$keyString" was disposed while initializing.',
            );
          }

          info.instance = instance;
          _initializeInstance(instance, keyString, info);
          _notifyResolve(keyString, info, 'findAsync');
          return instance;
        } finally {
          _pendingInit.remove(key);
        }
      })();

      _pendingInit[key] = future;
      return future;
    }

    // `findAsync` can resolve sync registrations when no async builder exists.
    return _findLocal<S>(info, keyString, tag);
  }

  S _findAliasLocal<S>({
    required LevitScopeKey aliasKey,
    required LevitScopeKey canonicalKey,
  }) {
    final info = _registry[canonicalKey]!;
    if (info.isAsync && !info.isInstantiated) {
      throw StateError(
        'LevitScope($name): Alias "${aliasKey.debugString}" targets an '
        'asynchronous registration. Use findAsync().',
      );
    }

    final instance = _findLocal<dynamic>(
      info,
      canonicalKey.debugString,
      canonicalKey.tag,
    );
    _notifyResolve(aliasKey.debugString, info, 'findAlias');
    return instance as S;
  }

  Future<S> _findAliasLocalAsync<S>({
    required LevitScopeKey aliasKey,
    required LevitScopeKey canonicalKey,
  }) async {
    final info = _registry[canonicalKey]!;

    final instance = await _findLocalAsync<dynamic>(
      info,
      canonicalKey,
      canonicalKey.debugString,
      canonicalKey.tag,
    );
    _notifyResolve(aliasKey.debugString, info, 'findAliasAsync');
    return instance as S;
  }

  S _findLocal<S>(LevitDependency<S> info, String key, String? tag) {
    if (info.isAsync && !info.isInstantiated) {
      throw StateError(
        'LevitScope($name): Type "$S"${tag != null ? ' with tag "$tag"' : ''} is registered as async and not yet instantiated. Use findAsync() to initialize it.',
      );
    }

    // Factories bypass cached instance storage.
    if (info.isFactory && info.builder != null) {
      final instance = _createInstance<S>(info.builder!, key, info);
      _initializeInstance(instance, key, info);
      _notifyResolve(key, info, 'find');
      return instance;
    }

    // Lazy singleton instantiates once and is reused afterward.
    if (info.isLazy && !info.isInstantiated) {
      info.instance = _createInstance<S>(info.builder!, key, info);
      _initializeInstance(info.instance, key, info);
      _notifyResolve(key, info, 'find');
    }

    return info.instance as S;
  }

  S _createInstance<S>(S Function() builder, String key, LevitDependency info) {
    final wrappedBuilder = _applyCreateInstanceHooks<S>(builder, key, info);
    return wrappedBuilder();
  }

  Future<S> _createInstanceAsync<S>(
      Future<S> Function() builder, String key, LevitDependency info) async {
    final wrappedBuilder =
        _applyCreateInstanceHooks<Future<S>>(builder, key, info);
    return wrappedBuilder();
  }

  void _initializeInstance(dynamic instance, String key, LevitDependency info) {
    if (instance is LevitScopeDisposable) {
      _applyInitHooks(instance, instance.onInit, key, info);
      instance.didAttachToScope(this, key: key);
    }
  }

  /// Returns `true` if type [S] is registered in this scope (parent scopes are ignored).
  bool isRegisteredLocally<S>({String? tag}) {
    final key = _getKey<S>(tag);
    return _registry.containsKey(key) || _aliases.containsKey(key);
  }

  /// Returns `true` if type [S] is registered in this scope or any ancestor.
  bool isRegistered<S>({String? tag}) {
    if (isRegisteredLocally<S>(tag: tag)) return true;
    if (_parentScope != null) return _parentScope!.isRegistered<S>(tag: tag);
    return false;
  }

  /// Returns `true` if the dependency [S] has already been instantiated.
  ///
  /// This checks if the lazy builder has executed or if the instance was put directly.
  bool isInstantiated<S>({String? tag}) {
    final key = _getKey<S>(tag);
    final local = _registry[key];
    if (local != null) {
      return local.isInstantiated;
    }
    final canonicalKey = _aliases[key];
    if (canonicalKey != null) {
      return _registry[canonicalKey]?.isInstantiated ?? false;
    }
    if (_parentScope != null) return _parentScope!.isInstantiated<S>(tag: tag);
    return false;
  }

  /// Removes a dependency from the scope.
  ///
  /// If the dependency is currently instantiated and implements [LevitScopeDisposable],
  /// its [LevitScopeDisposable.onClose] method will be called.
  ///
  /// Set [force] to `true` to delete dependencies marked as `permanent`.
  ///
  /// Returns `true` if the dependency was found and deleted.
  Future<bool> delete<S>({String? tag, bool force = false}) async {
    _ensureUsable();
    final key = _getKey<S>(tag);
    final keyString = key.debugString;

    if (_aliases.containsKey(key)) {
      final canonicalKey = _aliases[key]!;
      final info = _registry[canonicalKey];
      _removeAlias(key);
      if (info != null) {
        _notifyDelete(keyString, info, 'deleteAlias');
      }
      return true;
    }

    final info = _registry[key];
    if (info == null) return false;

    if (info.permanent && !force) return false;

    _notifyDelete(keyString, info, 'delete');
    _removeCanonicalBinding(key);

    if (info.isInstantiated) {
      await _disposeAll(<Object?>[info.instance]);
    }
    return true;
  }

  /// Disposes all dependencies registered in this scope.
  ///
  /// Dependencies marked as `permanent` are preserved unless [force] is `true`.
  Future<void> reset({bool force = false}) async {
    _ensureUsable();
    final entriesToRemove = <MapEntry<LevitScopeKey, LevitDependency>>[];

    for (final entry in _registry.entries.toList(growable: false)) {
      final info = entry.value;

      if (info.permanent && !force) continue;

      _notifyDelete(entry.key.debugString, info, 'reset');
      entriesToRemove.add(entry);
    }

    for (final entry in entriesToRemove) {
      _removeCanonicalBinding(entry.key);
    }

    if (force) {
      // Force reset also drops all lookup caches.
      _typeRegistry.clear();
      _typeResolutionCache.clear();
      _instanceCache.clear();
      _resolutionCache.clear();
    }

    await _disposeAll(
      entriesToRemove
          .where((entry) => entry.value.isInstantiated)
          .map((entry) => entry.value.instance)
          .toList(growable: false)
          .reversed,
    );
  }

  /// Disposes the scope and all its dependencies.
  ///
  /// This triggers a full cleanup. All middlewares are notified, and the scope
  /// is marked as unusable.
  Future<void> dispose() {
    return _disposeFuture ??= _disposeScope();
  }

  Future<void> _disposeScope() async {
    if (_isDisposed) return;
    _isClosing = true;

    Object? failure;
    StackTrace? failureStack;
    try {
      await _resetWhileClosing();
    } catch (error, stackTrace) {
      failure = error;
      failureStack = stackTrace;
    } finally {
      _isDisposed = true;
      _notifyScopeDispose();
    }

    if (failure != null) {
      Error.throwWithStackTrace(failure, failureStack!);
    }
  }

  /// Creates a new child scope.
  ///
  /// The child scope can register its own dependencies or shadow dependencies
  /// from this parent scope.
  ///
  /// [name] is used for debugging.
  LevitScope createScope(String name) {
    _ensureUsable();
    assert(() {
      LevitScope? current = this;
      while (current != null) {
        if (current.name == name) {
          _emitScopeDebugWarning(
            'LevitScope: Child scope "$name" has the same name as ancestor '
            'scope "${current.name}" (id: ${current.id}). '
            'Consider unique names for debugging clarity.',
          );
          break;
        }
        current = current._parentScope;
      }
      return true;
    }());
    return LevitScope._(name, parentScope: this);
  }

  Future<void> _resetWhileClosing() async {
    final entries = _registry.entries.toList(growable: false);

    for (final entry in entries) {
      _notifyDelete(entry.key.debugString, entry.value, 'dispose');
      _removeCanonicalBinding(entry.key);
    }

    _aliases.clear();
    _aliasesByCanonical.clear();
    _pendingInit.clear();
    _typeRegistry.clear();
    _typeResolutionCache.clear();
    _instanceCache.clear();
    _resolutionCache.clear();

    await _disposeAll(
      entries
          .where((entry) => entry.value.isInstantiated)
          .map((entry) => entry.value.instance)
          .toList(growable: false)
          .reversed,
    );
  }

  Future<void> _disposeAll(Iterable<Object?> instances) async {
    final failures = <LevitDisposalFailure>[];
    final seen = HashSet<Object>.identity();

    for (final instance in instances) {
      if (instance == null || !seen.add(instance)) continue;
      try {
        await _disposeInstance(instance);
      } catch (error, stackTrace) {
        failures.add(LevitDisposalFailure(
          resource: instance,
          error: error,
          stackTrace: stackTrace,
        ));
      }
    }

    if (failures.isNotEmpty) {
      throw LevitDisposalException(failures);
    }
  }

  Future<void> _disposeInstance(Object instance) async {
    if (instance is LevitScopeDisposable) {
      await instance.onClose();
      return;
    }
    if (instance is LevitDisposable) {
      await instance.dispose();
    }
  }

  void _removeCanonicalBinding(LevitScopeKey key) {
    _registry.remove(key);
    _pendingInit.remove(key);
    _invalidateLookupCaches(key);

    final aliases = _aliasesByCanonical.remove(key);
    if (aliases != null) {
      for (final alias in aliases.toList(growable: false)) {
        _aliases.remove(alias);
        _invalidateLookupCaches(alias);
      }
    }
  }

  void _removeAlias(LevitScopeKey aliasKey) {
    final canonicalKey = _aliases.remove(aliasKey);
    if (canonicalKey == null) return;

    final reverse = _aliasesByCanonical[canonicalKey];
    reverse?.remove(aliasKey);
    if (reverse != null && reverse.isEmpty) {
      _aliasesByCanonical.remove(canonicalKey);
    }
    _invalidateLookupCaches(aliasKey);
  }

  void _invalidateLookupCaches(LevitScopeKey key) {
    _resolutionCache.remove(key);
    if (key.tag == null) {
      _typeRegistry.remove(key.type);
      _typeResolutionCache.remove(key.type);
      _instanceCache.remove(key.type);
    }
  }

  void _ensureUsable() {
    if (_isClosing || _isDisposed) {
      throw StateError('LevitScope($name) is closing or disposed.');
    }
  }

  LevitScopeKey _getKey<S>(String? tag) => LevitScopeKey.of<S>(tag: tag);

  /// The number of dependencies registered locally in this scope.
  int get registeredCount => _registry.length + _aliases.length;

  /// A list of keys for all locally registered dependencies (for debugging).
  List<String> get registeredKeys => <LevitScopeKey>[
        ..._registry.keys,
        ..._aliases.keys
      ].map((k) => k.debugString).toList();

  @override
  String toString() {
    return 'LevitScope($name, $registeredCount local registrations)';
  }

  // Global scope middleware registry.
  static final List<LevitScopeMiddleware> _middlewares = [];
  static final Map<Object, LevitScopeMiddleware> _middlewaresByToken = {};

  /// Adds a global middleware to be notified of DI events.
  ///
  /// Registration is idempotent by instance identity.
  /// If [token] is provided, registration is unique per token:
  /// adding another middleware with the same token replaces the previous one.
  static void addMiddleware(LevitScopeMiddleware middleware, {Object? token}) {
    if (token != null) return _addMiddlewareWithToken(token, middleware);
    if (_middlewares.contains(middleware)) return;
    _middlewares.add(middleware);
  }

  static void _addMiddlewareWithToken(
      Object token, LevitScopeMiddleware middleware) {
    final existingByToken = _middlewaresByToken[token];
    if (existingByToken != null && !identical(existingByToken, middleware)) {
      return _replaceMiddlewareToken(existingByToken, token, middleware);
    }
    if (existingByToken == null) _attachMiddlewareToken(token, middleware);
  }

  static void _attachMiddlewareToken(
      Object token, LevitScopeMiddleware middleware) {
    if (_middlewares.contains(middleware)) {
      _middlewaresByToken[token] = middleware;
      return;
    }
    _middlewares.add(middleware);
    _middlewaresByToken[token] = middleware;
  }

  static void _replaceMiddlewareToken(
    LevitScopeMiddleware existingByToken,
    Object token,
    LevitScopeMiddleware middleware,
  ) {
    _replaceOrAppendMiddleware(existingByToken, middleware);
    _middlewaresByToken[token] = middleware;
  }

  static void _replaceOrAppendMiddleware(
      LevitScopeMiddleware existing, LevitScopeMiddleware replacement) {
    final index = _middlewares.indexOf(existing);
    if (index >= 0) {
      _middlewares[index] = replacement;
    } else {
      _middlewares.add(replacement);
    }
  }

  /// Removes a previously added middleware.
  static void removeMiddleware(LevitScopeMiddleware middleware) {
    if (_middlewares.remove(middleware)) {
      _middlewaresByToken
          .removeWhere((_, registered) => identical(registered, middleware));
    }
  }

  /// Removes a middleware by [token].
  static bool removeMiddlewareByToken(Object token) {
    final middleware = _middlewaresByToken.remove(token);
    return middleware != null && _middlewares.remove(middleware);
  }

  static bool containsMiddleware(LevitScopeMiddleware middleware) =>
      _middlewares.contains(middleware);
  static bool containsMiddlewareToken(Object token) =>
      _middlewaresByToken.containsKey(token);
  static bool get hasMiddlewares => _middlewares.isNotEmpty;

  void _notifyRegister(String key, LevitDependency info, String source) {
    _LevitScopeMiddlewareChain.applyOnRegister(
        id, name, key, info, source, _parentScope?.id);
  }

  void _notifyResolve(String key, LevitDependency info, String source) {
    _LevitScopeMiddlewareChain.applyOnResolve(
        id, name, key, info, source, _parentScope?.id);
  }

  S Function() _applyCreateInstanceHooks<S>(
    S Function() builder,
    String key,
    LevitDependency info,
  ) {
    return _LevitScopeMiddlewareChain.applyOnCreate<S>(
        builder, this, key, info);
  }

  void _notifyDelete(String key, LevitDependency info, String source) {
    _LevitScopeMiddlewareChain.applyOnDelete(
        id, name, key, info, source, _parentScope?.id);
  }

  void _applyInitHooks<S>(
    S instance,
    void Function() onInit,
    String key,
    LevitDependency info,
  ) {
    final wrapped = _LevitScopeMiddlewareChain.applyOnDependencyInit<S>(
        onInit, instance, this, key, info);
    wrapped();
  }

  void _notifyScopeCreate() {
    _LevitScopeMiddlewareChain.applyOnScopeCreate(id, name, _parentScope?.id);
  }

  void _notifyScopeDispose() {
    _LevitScopeMiddlewareChain.applyOnScopeDispose(id, name);
  }
}

void _emitScopeDebugWarning(String message) {
  dev.log(message, name: 'levit_scope');
  Zone.current.print(message);
}

/// Internal helper to apply observer hooks in a single place.
///
/// Consolidates iteration logic for better maintainability and optimization.
class _LevitScopeMiddlewareChain {
  static S Function() applyOnCreate<S>(
    S Function() builder,
    LevitScope scope,
    String key,
    LevitDependency info,
  ) {
    if (LevitScope._middlewares.isEmpty) return builder;
    var wrapped = builder;
    for (final observer in LevitScope._middlewares) {
      wrapped = observer.onDependencyCreate<S>(wrapped, scope, key, info);
    }
    return wrapped;
  }

  static void Function() applyOnDependencyInit<S>(
    void Function() onInit,
    S instance,
    LevitScope scope,
    String key,
    LevitDependency info,
  ) {
    if (LevitScope._middlewares.isEmpty) return onInit;
    var wrapped = onInit;
    for (final observer in LevitScope._middlewares) {
      wrapped =
          observer.onDependencyInit<S>(wrapped, instance, scope, key, info);
    }
    return wrapped;
  }

  static void applyOnRegister(int scopeId, String scopeName, String key,
      LevitDependency info, String source, int? parentScopeId) {
    if (LevitScope._middlewares.isEmpty) return;
    for (final observer in LevitScope._middlewares) {
      observer.onDependencyRegister(scopeId, scopeName, key, info,
          source: source, parentScopeId: parentScopeId);
    }
  }

  static void applyOnResolve(int scopeId, String scopeName, String key,
      LevitDependency info, String source, int? parentScopeId) {
    if (LevitScope._middlewares.isEmpty) return;
    for (final observer in LevitScope._middlewares) {
      observer.onDependencyResolve(scopeId, scopeName, key, info,
          source: source, parentScopeId: parentScopeId);
    }
  }

  static void applyOnDelete(int scopeId, String scopeName, String key,
      LevitDependency info, String source, int? parentScopeId) {
    if (LevitScope._middlewares.isEmpty) return;
    for (final observer in LevitScope._middlewares) {
      observer.onDependencyDelete(scopeId, scopeName, key, info,
          source: source, parentScopeId: parentScopeId);
    }
  }

  static void applyOnScopeCreate(
      int scopeId, String scopeName, int? parentScopeId) {
    if (LevitScope._middlewares.isEmpty) return;
    for (final observer in LevitScope._middlewares) {
      observer.onScopeCreate(scopeId, scopeName, parentScopeId);
    }
  }

  static void applyOnScopeDispose(int scopeId, String scopeName) {
    if (LevitScope._middlewares.isEmpty) return;
    for (final observer in LevitScope._middlewares) {
      observer.onScopeDispose(scopeId, scopeName);
    }
  }
}

/// Extension to convert any object to a builder function.
extension LevitScopeToBuilderExtension<T> on T {
  /// Converts the current instance into a lazy builder function that returns it.
  T Function() get toBuilder => () => this;
}
