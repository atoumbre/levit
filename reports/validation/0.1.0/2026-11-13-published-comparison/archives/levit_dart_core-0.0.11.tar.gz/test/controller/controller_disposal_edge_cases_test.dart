import 'dart:async';
import 'package:levit_dart_core/levit_dart_core.dart';
import 'package:test/test.dart';

class TestController extends LevitController {}

class ThrowingDisposable {
  void dispose() => throw Exception('Dispose failed');
}

class ThrowingCancelable {
  void cancel() => throw Exception('Cancel failed');
}

class ThrowingCloseable {
  void close() => throw Exception('Close failed');
}

void main() {
  group('LevitController Disposal Edge Cases', () {
    test('autoDispose handles Timer and Sink', () {
      final controller = TestController();
      final timer = Timer(const Duration(hours: 1), () {});
      controller.autoDispose(timer);

      final sc = StreamController<int>();
      controller.autoDispose(sc.sink);

      controller.onClose();
      expect(timer.isActive, false);
      expect(sc.isClosed, true);
    });

    test('autoDispose handles StreamSubscription', () async {
      final controller = TestController();
      var cancelCalled = false;
      final streamController = StreamController<int>.broadcast(
        onCancel: () {
          cancelCalled = true;
        },
      );
      final subscription = streamController.stream.listen((_) {});
      controller.autoDispose(subscription);

      controller.onClose();
      await Future<void>.delayed(Duration.zero);

      expect(cancelCalled, isTrue);
      await streamController.close();
    });

    test('autoDispose aggregates exceptions after cleanup', () async {
      final controller = TestController();

      controller.autoDispose(ThrowingDisposable());
      controller.autoDispose(ThrowingCancelable());
      controller.autoDispose(ThrowingCloseable());

      await expectLater(
        controller.onClose(),
        throwsA(
          isA<LevitDisposalException>().having(
            (error) => error.failures.length,
            'failure count',
            3,
          ),
        ),
      );
      expect(controller.isClosed, isTrue);
    });

    test('identical objects are not added twice', () {
      final controller = TestController();
      final timer = Timer(Duration.zero, () {});
      controller.autoDispose(timer);
      controller.autoDispose(timer);
      controller.onClose();
    });
  });
}
